package com.mindtree.mallbrand;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirportflightpassengerApplicationTests {

	@Test
	void contextLoads() {
	}

}
