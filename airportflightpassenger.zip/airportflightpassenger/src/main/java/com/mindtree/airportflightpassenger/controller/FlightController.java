package com.mindtree.airportflightpassenger.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.airportflightpassenger.dto.FlightDto;
import com.mindtree.airportflightpassenger.exception.ApplicationException;
import com.mindtree.airportflightpassenger.service.FlightService;

@RestController
public class FlightController {
	@Autowired
	private FlightService flightService;

	@PostMapping(value = "/addFlight")
	public ResponseEntity<?> addFlight(@RequestBody FlightDto flightDto) throws ApplicationException {
		FlightDto flightDto2 = flightService.addFlight(flightDto);
		return new ResponseEntity<FlightDto>(flightDto2, HttpStatus.ACCEPTED);
	}

	@PutMapping(value = "/registerFlight/{airportId}/{flightId}")
	public ResponseEntity<?> registerFlightToAirport(@PathVariable int airportId, @PathVariable String flightId)
			throws ApplicationException {
		String str = flightService.registerFlightToAirport(airportId, flightId);
		return new ResponseEntity<String>(str, HttpStatus.ACCEPTED);

	}
	
	@DeleteMapping(value="/deleteFlight/{flightName}")
	public ResponseEntity<?> deleteOnlyFlight(@PathVariable String flightName) throws ApplicationException{
		String str=flightService.deleteFlightById(flightName);
		return new ResponseEntity<String>(str, HttpStatus.ACCEPTED);
	}
	

}
