package com.mindtree.airportflightpassenger.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.airportflightpassenger.dto.PassengerDto;
import com.mindtree.airportflightpassenger.exception.ApplicationException;
import com.mindtree.airportflightpassenger.service.PassengerService;

@RestController
public class PassengerController {

	@Autowired
	private PassengerService passengerService;

	@PostMapping(value = "/addPassenger")
	public ResponseEntity<?> addPassenger(@RequestBody PassengerDto passengerDto) {
		PassengerDto passengerDto1 = passengerService.addPassenger(passengerDto);
		return new ResponseEntity<PassengerDto>(passengerDto1, HttpStatus.ACCEPTED);

	}
	
	@PutMapping(value="/registerPassenger/{flightId}/{passengerId}")
	public ResponseEntity<?> registerPassengerToFlight(@PathVariable String flightId,@PathVariable int passengerId) throws ApplicationException{
		String str=passengerService.registerPassengerToFlight(flightId,passengerId);
		return new ResponseEntity<String>(str, HttpStatus.ACCEPTED);

}
}
