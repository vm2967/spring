package com.mindtree.airportflightpassenger.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Flight {
	@Id
	private String flightId;
	private String flightName;
	private int totalPassengers;
	private double ticketCost;
	private double totalRevenueGenerated;
	
	@JsonIgnore
	@ManyToMany(fetch = FetchType.LAZY,cascade = CascadeType.PERSIST)
	List<Airport> airports;
	
	@ManyToMany(fetch = FetchType.LAZY,cascade = CascadeType.PERSIST,mappedBy = "flights")
	List<Passenger> passengers;

	public Flight() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public Flight(String flightId, String flightName, int totalPassengers, double ticketCost,
			double totalRevenueGenerated, List<Airport> airports, List<Passenger> passengers) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.totalPassengers = totalPassengers;
		this.ticketCost = ticketCost;
		this.totalRevenueGenerated = totalRevenueGenerated;
		this.airports = airports;
		this.passengers = passengers;
	}



	public String getFlightId() {
		return flightId;
	}


	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}


	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public int getTotalPassengers() {
		return totalPassengers;
	}

	public void setTotalPassengers(int totalPassengers) {
		this.totalPassengers = totalPassengers;
	}

	public double getTicketCost() {
		return ticketCost;
	}

	public void setTicketCost(double ticketCost) {
		this.ticketCost = ticketCost;
	}

	public double getTotalRevenueGenerated() {
		return totalRevenueGenerated;
	}

	public void setTotalRevenueGenerated(double totalRevenueGenerated) {
		this.totalRevenueGenerated = totalRevenueGenerated;
	}

	public List<Airport> getAirports() {
		return airports;
	}

	public void setAirports(List<Airport> airports) {
		this.airports = airports;
	}

	public List<Passenger> getPassengers() {
		return passengers;
	}

	public void setPassengers(List<Passenger> passengers) {
		this.passengers = passengers;
	}
	
	
	
	

}
