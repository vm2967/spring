package com.mindtree.airportflightpassenger.service.serviceimpli;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.airportflightpassenger.dto.PassengerDto;
import com.mindtree.airportflightpassenger.entity.Flight;
import com.mindtree.airportflightpassenger.entity.Passenger;
import com.mindtree.airportflightpassenger.exception.FlightNotFoundException;
import com.mindtree.airportflightpassenger.exception.InsufficientFundsException;
import com.mindtree.airportflightpassenger.exception.PassengerNotFoundException;
import com.mindtree.airportflightpassenger.exception.ServiceException;
import com.mindtree.airportflightpassenger.repository.FlightRepository;
import com.mindtree.airportflightpassenger.repository.PassengerRepository;
import com.mindtree.airportflightpassenger.service.PassengerService;

@Service
public class PassengerServiceImpli implements PassengerService {

	@Autowired
	private PassengerRepository passengerRepo;
	@Autowired
	private FlightRepository flightRepo;

	@Autowired
	private ModelMapper modelMapper;

	@Override
	public PassengerDto addPassenger(PassengerDto passengerDto) {
		Passenger passenger = modelMapper.map(passengerDto, Passenger.class);
		passengerRepo.save(passenger);
		return passengerDto;
	}

	@Override
	public String registerPassengerToFlight(String flightId, int passengerId) throws ServiceException {
		Flight flight = flightRepo.findById(flightId)
				.orElseThrow(() -> new FlightNotFoundException("Flight Not Found"));
		Passenger passenger = passengerRepo.findById(passengerId)
				.orElseThrow(() -> new PassengerNotFoundException("Passenger Not Found"));
		if (passenger.getAccountBalance() < flight.getTicketCost()) {
			throw new InsufficientFundsException("Funds in your Account balance is low");
		} else {
			flight.setTotalRevenueGenerated(
					flight.getTotalRevenueGenerated() + (flight.getTicketCost()));
			passenger.setAccountBalance(passenger.getAccountBalance() - flight.getTicketCost());
			flight.getPassengers().add(passenger);
			passenger.getFlights().add(flight);
			passengerRepo.save(passenger);
			flightRepo.save(flight);
		}
		return "registered Successfully";
	}

}
