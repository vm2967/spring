package com.mindtree.airportflightpassenger.dto;

import java.util.List;

public class PassengerDto {

	private int passengerId;
	private String passengerName;
	private double accountBalance;
	
	
	private List<FlightDto> flights;


	public PassengerDto() {
		super();
		// TODO Auto-generated constructor stub
	}


	public PassengerDto(int passengerId, String passengerName, double accountBalance, List<FlightDto> flights) {
		super();
		this.passengerId = passengerId;
		this.passengerName = passengerName;
		this.accountBalance = accountBalance;
		this.flights = flights;
	}


	public int getPassengerId() {
		return passengerId;
	}


	public void setPassengerId(int passengerId) {
		this.passengerId = passengerId;
	}


	public String getPassengerName() {
		return passengerName;
	}


	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}


	public double getAccountBalance() {
		return accountBalance;
	}


	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}


	public List<FlightDto> getFlights() {
		return flights;
	}


	public void setFlights(List<FlightDto> flights) {
		this.flights = flights;
	}
	
	
}
