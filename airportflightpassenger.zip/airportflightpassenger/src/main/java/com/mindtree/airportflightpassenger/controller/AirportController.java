package com.mindtree.airportflightpassenger.controller;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.airportflightpassenger.dto.AirportDto;
import com.mindtree.airportflightpassenger.service.AirportService;

@RestController
public class AirportController {
	@Autowired
	private AirportService airportService;
	
	@PostMapping(value="/addAirport")
	public ResponseEntity<?> addAirport(@RequestBody AirportDto airportDto){
		
		AirportDto airportDto1=airportService.addAirport(airportDto);
		return new ResponseEntity<AirportDto>(airportDto1, HttpStatus.ACCEPTED);
		
	}
	@GetMapping(value="/getAirportsRevenue")
	public ResponseEntity<?> displayRevenueOfAirports(){
		Map<String, Double> airportList=airportService.displayAllAirportsRevenue();
		return new ResponseEntity<Map<String, Double>>(airportList, HttpStatus.FOUND);
		
	}

}
