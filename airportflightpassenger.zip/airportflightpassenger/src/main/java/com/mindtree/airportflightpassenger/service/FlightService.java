package com.mindtree.airportflightpassenger.service;

import com.mindtree.airportflightpassenger.dto.FlightDto;
import com.mindtree.airportflightpassenger.exception.ServiceException;

/**
 * @author M1057754
 *
 */
public interface FlightService {

	/**
	 * @param flightDto
	 * @return Object
	 * @throws ServiceException 
	 */
	FlightDto addFlight(FlightDto flightDto) throws ServiceException;

	/**
	 * @param airportId
	 * @param flightId
	 * @return String
	 * @throws ServiceException 
	 */
	/**
	 * @param airportId
	 * @param flightId
	 * @return String
	 * @throws ServiceException
	 */
	String registerFlightToAirport(int airportId, String flightId) throws ServiceException;

	/**
	 * @param flightName
	 * @return String
	 * @throws ServiceException 
	 */
	String deleteFlightById(String flightName) throws ServiceException;

}
