package com.mindtree.airportflightpassenger.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class FlightDto {
	private String flightId;
	private String flightName;
	private int totalPassengers;
	private double ticketCost;
	private double totalRevenueGenerated;

	@JsonIgnore
	List<AirportDto> airports;

	List<PassengerDto> passengers;

	public FlightDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FlightDto(String flightId, String flightName, int totalPassengers, double ticketCost,
			double totalRevenueGenerated, List<AirportDto> airports, List<PassengerDto> passengers) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.totalPassengers = totalPassengers;
		this.ticketCost = ticketCost;
		this.totalRevenueGenerated = totalRevenueGenerated;
		this.airports = airports;
		this.passengers = passengers;
	}

	public String getFlightId() {
		return flightId;
	}

	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public int getTotalPassengers() {
		return totalPassengers;
	}

	public void setTotalPassengers(int totalPassengers) {
		this.totalPassengers = totalPassengers;
	}

	public double getTicketCost() {
		return ticketCost;
	}

	public void setTicketCost(double ticketCost) {
		this.ticketCost = ticketCost;
	}

	public double getTotalRevenueGenerated() {
		return totalRevenueGenerated;
	}

	public void setTotalRevenueGenerated(double totalRevenueGenerated) {
		this.totalRevenueGenerated = totalRevenueGenerated;
	}

	public List<AirportDto> getAirports() {
		return airports;
	}

	public void setAirports(List<AirportDto> airports) {
		this.airports = airports;
	}

	public List<PassengerDto> getPassengers() {
		return passengers;
	}

	public void setPassengers(List<PassengerDto> passengers) {
		this.passengers = passengers;
	}

}
