package com.mindtree.airportflightpassenger.service;

import com.mindtree.airportflightpassenger.dto.PassengerDto;
import com.mindtree.airportflightpassenger.exception.ServiceException;

/**
 * @author M1057754
 *
 */
public interface PassengerService {

	/**
	 * @param passengerDto
	 * @return Object
	 */
	PassengerDto addPassenger(PassengerDto passengerDto);

	/**
	 * @param flightId
	 * @param passengerId
	 * @return String
	 * @throws ServiceException 
	 */
	String registerPassengerToFlight(String flightId, int passengerId) throws ServiceException;

}
