package com.mindtree.airportflightpassenger.service;


import java.util.Map;

import com.mindtree.airportflightpassenger.dto.AirportDto;


/**
 * @author M1057754
 *
 */
public interface AirportService {

	/**
	 * @param airportDto
	 * @return Object
	 */
	AirportDto addAirport(AirportDto airportDto);

	
	/**
	 * @return map
	 */
	Map<String, Double> displayAllAirportsRevenue();

}
