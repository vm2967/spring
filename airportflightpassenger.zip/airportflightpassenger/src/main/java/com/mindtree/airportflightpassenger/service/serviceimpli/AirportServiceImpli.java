package com.mindtree.airportflightpassenger.service.serviceimpli;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindtree.airportflightpassenger.dto.AirportDto;
import com.mindtree.airportflightpassenger.entity.Airport;

import com.mindtree.airportflightpassenger.repository.AirportRepository;
import com.mindtree.airportflightpassenger.service.AirportService;

@Service
public class AirportServiceImpli implements AirportService {

	@Autowired
	private AirportRepository airportRepo;

	@Autowired
	private ModelMapper modelMapper;

	@Override
	public AirportDto addAirport(AirportDto airportDto) {
		Airport airport = modelMapper.map(airportDto, Airport.class);
		airportRepo.save(airport);
		return airportDto;
	}

	@Override
	public Map<String, Double> displayAllAirportsRevenue() {
		List<Airport> airportList = airportRepo.findAll();
		airportList.forEach(e -> e.getFlights());
		Map<String, Double> airportMapData = new HashMap<String, Double>();
		for (Airport airport : airportList) {
			airportMapData.put(airport.getAirportName(), airport.getFlights().stream().mapToDouble(f -> f.getTotalRevenueGenerated())
					.reduce(0, (a, b) -> a + b));
			airport.setTotalData(airportMapData);
		}
		
		return airportMapData;
	}

}
