package com.mindtree.airportflightpassenger.repository;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mindtree.airportflightpassenger.entity.Flight;

@Repository
public interface FlightRepository extends JpaRepository<Flight, String> {
	
	@Transactional
	@Modifying
	@Query(value="delete from Flight f where flightName=?1")
	void deleteFlightByFlightName(String flightName);
	
	public Optional<Flight> findByFlightName(String flightName);
	

	

}
