package com.mindtree.airportflightpassenger.service.serviceimpli;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.airportflightpassenger.dto.FlightDto;
import com.mindtree.airportflightpassenger.entity.Airport;
import com.mindtree.airportflightpassenger.entity.Flight;
import com.mindtree.airportflightpassenger.exception.AirportNotFoundException;
import com.mindtree.airportflightpassenger.exception.FlightExceedingException;
import com.mindtree.airportflightpassenger.exception.FlightIdExistsException;
import com.mindtree.airportflightpassenger.exception.FlightNameSameException;
import com.mindtree.airportflightpassenger.exception.FlightNotFoundException;
import com.mindtree.airportflightpassenger.exception.ServiceException;
import com.mindtree.airportflightpassenger.repository.AirportRepository;
import com.mindtree.airportflightpassenger.repository.FlightRepository;
import com.mindtree.airportflightpassenger.service.FlightService;

@Service
public class FlightServiceImpli implements FlightService {

	@Autowired
	private FlightRepository flightRepo;

	@Autowired
	private AirportRepository airportRepo;

	@Autowired
	private ModelMapper modelMapper;

	@Override
	public FlightDto addFlight(FlightDto flightDto) throws ServiceException {
		List<Flight> flightList = flightRepo.findAll();
		boolean flag = false;
		if (flightList != null) {
			flag = flightList.stream().anyMatch(f -> f.getFlightName().equals(flightDto.getFlightName()));
		}
		if (flag == true) {
			throw new FlightNameSameException("Flight Name Already Exists");
		}
		if (flightList != null) {
			flag = flightList.stream().anyMatch(f -> f.getFlightId().equals(flightDto.getFlightId()));
		}
		if (flag == true) {
			throw new FlightIdExistsException("Flight ID Already Exists");
		} else {
			Flight flight = modelMapper.map(flightDto, Flight.class);
			flightRepo.save(flight);
			return flightDto;
		}
	}

	@Override
	public String registerFlightToAirport(int airportId, String flightId) throws ServiceException {
		Airport airport = airportRepo.findById(airportId)
				.orElseThrow(() -> new AirportNotFoundException("Airport Not Found"));
		if (airport.getTotalFlights() == airport.getFlights().size()) {
			throw new FlightExceedingException("Flights are excceding the range of airport Flights");
		} else {
			Flight flight = flightRepo.findById(flightId)
					.orElseThrow(() -> new FlightNotFoundException("Flight Not Found"));
			flight.getAirports().add(airport);
			airport.getFlights().add(flight);
			flightRepo.save(flight);
			airportRepo.save(airport);
		}
		return "registered Successfully";
	}
	
	@Override
	public String deleteFlightById(String flightName) throws ServiceException {
		Flight flight=flightRepo.findByFlightName(flightName).orElseThrow(()->new FlightNotFoundException("Flight Not Found"));
		flightRepo.deleteFlightByFlightName(flightName);
		return "deleted Successfully";
	}
	

}
