package com.mindtree.airportflightpassenger.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;


public class AirportDto {
	
	private int airportId;
	private String airportName;
	private int totalFlights;
	
	
	List<FlightDto> flights;
	
	@JsonIgnore
	private Map<String, Double> totalData=new HashMap<String, Double>();

	public AirportDto() {
		super();
		
	}

	

	public AirportDto(int airportId, String airportName, int totalFlights, List<FlightDto> flights,
			Map<String, Double> totalData) {
		super();
		this.airportId = airportId;
		this.airportName = airportName;
		this.totalFlights = totalFlights;
		this.flights = flights;
		this.totalData = totalData;
	}



	public int getAirportId() {
		return airportId;
	}

	public void setAirportId(int airportId) {
		this.airportId = airportId;
	}

	public String getAirportName() {
		return airportName;
	}

	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}

	public int getTotalFlights() {
		return totalFlights;
	}

	public void setTotalFlights(int totalFlights) {
		this.totalFlights = totalFlights;
	}

	public List<FlightDto> getFlights() {
		return flights;
	}

	public void setFlights(List<FlightDto> flights) {
		this.flights = flights;
	}



	public Map<String, Double> getTotalData() {
		return totalData;
	}



	public void setTotalData(Map<String, Double> totalData) {
		this.totalData = totalData;
	}
	
	
	
}
