package com.mindtree.airportflightpassenger.entity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.MapKeyColumn;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Airport {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int airportId;
	private String airportName;
	private int totalFlights;
	
	@ManyToMany(fetch = FetchType.LAZY,cascade = CascadeType.PERSIST,mappedBy = "airports")
	List<Flight> flights;
	
	@ElementCollection
	@MapKeyColumn
	@JsonIgnore
	private Map<String, Double> totalData=new HashMap<String, Double>();

	public Airport() {
		super();
		
	}


	public Airport(int airportId, String airportName, int totalFlights, List<Flight> flights,
			Map<String, Double> totalData) {
		super();
		this.airportId = airportId;
		this.airportName = airportName;
		this.totalFlights = totalFlights;
		this.flights = flights;
		this.totalData = totalData;
	}


	public int getAirportId() {
		return airportId;
	}

	public void setAirportId(int airportId) {
		this.airportId = airportId;
	}

	public String getAirportName() {
		return airportName;
	}

	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}

	public int getTotalFlights() {
		return totalFlights;
	}

	public void setTotalFlights(int totalFlights) {
		this.totalFlights = totalFlights;
	}

	public List<Flight> getFlights() {
		return flights;
	}

	public void setFlights(List<Flight> flights) {
		this.flights = flights;
	}


	public Map<String, Double> getTotalData() {
		return totalData;
	}


	public void setTotalData(Map<String, Double> totalData) {
		this.totalData = totalData;
	}


	
	

}
