package client;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Client {

	public static void main(String[] args) {
		read();
		
	}
	@SuppressWarnings({ "deprecation", "unused" })
	public static void read() {
		try {
			FileInputStream fis = new FileInputStream("D:/userdetailsnew.xlsx");
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet("user newdetails");
			Iterator<Row> rowiter = sheet.iterator();
//			XSSFWorkbook book1=new XSSFWorkbook();
//			XSSFSheet sheet2= book1.createSheet("user details");
			int row = 0;
			while (rowiter.hasNext()) {
				Row rownext = rowiter.next();
				Iterator<Cell> celliterator = rownext.iterator();
				// Row row1=sheet2.createRow(row++);
				int column = 0;
				while (celliterator.hasNext()) {
					Cell cell = celliterator.next();
					// Cell cell1=row1.createCell(column++);
					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_NUMERIC:
						// cell1.setCellValue(cell.getNumericCellValue());
						// cell1=row1.createCell(column++);
						break;
					case Cell.CELL_TYPE_STRING:
						// cell1.setCellValue(cell.getStringCellValue());
						// cell1=row1.createCell(column++);
						break;

					}

				}

			}
			// File file = new File("D:/userdetailsnew.xlsx");
			File file1 = new File("san.xlsx");
			file1.createNewFile();
			FileOutputStream out1 = new FileOutputStream(file1);
			workbook.write(out1);
			Desktop d = Desktop.getDesktop();
			d.open(file1);
			// FileOutputStream out=new FileOutputStream(file);
			// book1.write(out);
			workbook.close();
			fis.close();

		} catch (IOException e) {

			System.out.println(e.getMessage());
		}

	}

}
