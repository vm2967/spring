package entity;

public class User {
	
	private int userId;
	private String userName;
	private int userAge;
	private int userSalary;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(int userId, String userName, int userAge, int userSalary) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userAge = userAge;
		this.userSalary = userSalary;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getUserAge() {
		return userAge;
	}
	public void setUserAge(int userAge) {
		this.userAge = userAge;
	}
	public int getUserSalary() {
		return userSalary;
	}
	public void setUserSalary(int userSalary) {
		this.userSalary = userSalary;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userAge=" + userAge + ", userSalary="
				+ userSalary + "]";
	}
	
	

}
