package com.example.demo.serviceInterface;

import com.example.demo.entity.College;
import com.example.demo.exception.ServiceException;

public interface CollegeInterface {

	String add(int universityId, College colleg) throws ServiceException;

}
