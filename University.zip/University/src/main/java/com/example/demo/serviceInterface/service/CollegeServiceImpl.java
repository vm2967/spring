package com.example.demo.serviceInterface.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.College;
import com.example.demo.entity.University;
import com.example.demo.exception.CollegeCountExceededException;
import com.example.demo.exception.ServiceException;
import com.example.demo.repository.CollegeRepository;
import com.example.demo.repository.UniversityRepository;
import com.example.demo.serviceInterface.CollegeInterface;
@Service
public class CollegeServiceImpl implements CollegeInterface {
	@Autowired
	UniversityRepository universityRepo;
	@Autowired
	CollegeRepository collegeRepo;

	@Override
	public String add(int universityId, College colleg) throws ServiceException{
	University university=	universityRepo.findById(universityId).orElse(null);
	try {
	if(university.getTotalColleges()==university.getCollege().size())
	{
		throw new CollegeCountExceededException("college could not be added");
	}
		else
		{
			colleg.setUniversity(university);
			collegeRepo.save(colleg);
		}
		
		return "College registered successfully";
	}
	catch(CollegeCountExceededException e)
	{
		throw new ServiceException(e.getMessage());
	}
	
	

}
}
