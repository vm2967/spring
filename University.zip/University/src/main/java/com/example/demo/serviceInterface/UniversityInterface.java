package com.example.demo.serviceInterface;




import java.util.List;

import com.example.demo.entity.College;
import com.example.demo.entity.University;

public interface UniversityInterface {

	String addUniver(University university);

	List<College> findColl(int universityId);

	List<University> getAllUniver();

	

}
