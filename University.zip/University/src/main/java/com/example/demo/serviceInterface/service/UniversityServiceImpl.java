package com.example.demo.serviceInterface.service;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.College;
import com.example.demo.entity.University;
import com.example.demo.repository.CollegeRepository;
import com.example.demo.repository.UniversityRepository;
import com.example.demo.serviceInterface.UniversityInterface;

@Service
public class UniversityServiceImpl implements UniversityInterface{
	@Autowired
	UniversityRepository universityRepo;
	@Autowired
	CollegeRepository collegeRepo;

	@Override
	public String addUniver(University university) {
		universityRepo.save(university);
		return "added Successfully";
	}

	@Override
	public List<College> findColl(int universityId) {		
	University uni= universityRepo.findById(universityId).orElse(null);
	List<College>li=new ArrayList<>();
	for (College coll : uni.getCollege()) {
		if(coll.getTotalStudents()>2)
		{
			li.add(coll);
			
		}
		
	}
	return li;
	
		
	}

	@Override
	public List<University> getAllUniver() {
		List<University> uni=universityRepo.findAll();
		return uni;
	}

	

}
