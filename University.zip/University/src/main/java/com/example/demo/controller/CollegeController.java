package com.example.demo.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entity.College;
import com.example.demo.entity.University;
import com.example.demo.exception.ApplicationException;
import com.example.demo.exception.ServiceException;
import com.example.demo.serviceInterface.CollegeInterface;
import com.example.demo.serviceInterface.UniversityInterface;

@RestController

public class CollegeController {
	@Autowired
	CollegeInterface collegeInterface;
	
	@Autowired
	UniversityInterface universityInterface;

	@PostMapping(value = "/addCollege/{universityId}")
	public ResponseEntity<?> addCollege(@PathVariable int universityId, @RequestBody College colleg) {
		String c = "";
		try {
			c = collegeInterface.add(universityId, colleg);
		} catch (ServiceException e) {
			try {
				throw new ApplicationException(e.getMessage());
			} catch (ApplicationException e1) {
				return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
			}

		}
		return new ResponseEntity<String>(c, HttpStatus.ACCEPTED);
	}

	@GetMapping(value = "/getAllUniversity")
	public ResponseEntity<?> getAll() {
		List<University> lis = universityInterface.getAllUniver();

		return new ResponseEntity<List<University>>(lis, HttpStatus.FOUND);
	}

}
