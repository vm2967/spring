package com.example.demo.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entity.College;
import com.example.demo.entity.University;
import com.example.demo.serviceInterface.UniversityInterface;

@RestController

public class UniversityController {
	@Autowired
	UniversityInterface universityInterface;
	
	@PostMapping(value="/add")
	public ResponseEntity<String> addUniversity(@RequestBody University university){
		String uni=universityInterface.addUniver(university);
		return new ResponseEntity<String>(uni, HttpStatus.ACCEPTED);
	}
	@GetMapping(value="/getCollege/{universityId}")
	public ResponseEntity<List<College>> getCollege(@PathVariable int universityId){
		List<College> college =universityInterface.findColl(universityId);
		return new ResponseEntity<List<College>>(college, HttpStatus.FOUND);
		
	}

}
