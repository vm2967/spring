package client;

public class Thread2 {
	public static void main(String[] args) {
		WaitAndNotify w=new WaitAndNotify(1,10);
		Thread thread1=new Thread(w.run1);
		Thread thread2=new Thread(w.run2);
		thread1.start();
		thread2.start();
	}

}
