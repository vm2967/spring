package client;

public class WaitAndNotify {

	int first;
	int last;

	public WaitAndNotify() {
		super();

	}
	public WaitAndNotify(int first, int last) {
		super();
		this.first = first;
		this.last = last;
	}

	Runnable run1 = () -> {

		while (this.first <= this.last) {

			synchronized (this) {
				if (first % 2 != 0) {
					System.out.println("2" + "x" + first + " = " + (first * 2));
					first++;
					this.notify();
				} else {
					try {
						this.wait();
					} catch (InterruptedException e) {

						e.printStackTrace();
					}
				}

			}
		}
	};

	Runnable run2 = () -> {

		while (this.first <= this.last) {
			
			synchronized (this) {
				if (first % 2 == 0) {
					System.out.println("2" + "+" + first + " = " + (first + 2));
					first++;
					this.notify();
				} else {
					try {
						this.wait();
					} catch (InterruptedException e) {

						e.printStackTrace();
					}
				}

			}
		}

	};

}
