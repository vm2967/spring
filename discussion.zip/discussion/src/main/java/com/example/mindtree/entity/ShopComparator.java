package com.example.mindtree.entity;

import java.util.Comparator;

public class ShopComparator implements Comparator<Shops>{

	@Override
	public int compare(Shops o1, Shops o2) {
		double result=o2.getTotalRevenue()-o1.getTotalRevenue();
		if(result!=0) {
			return (int) result;
		}
		else {
			return o2.getShopName().compareTo(o1.getShopName());
		}
	}
	

}
