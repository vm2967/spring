package com.example.mindtree.dto;

import com.example.mindtree.entity.Mall;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class ShopsDto {
	private String shopName;
	private double totalRevenue;
	@JsonIgnore
	private Mall mall;
	public ShopsDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ShopsDto(String shopName, double totalRevenue, Mall mall) {
		super();
		this.shopName = shopName;
		this.totalRevenue = totalRevenue;
		this.mall = mall;
	}
	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public double getTotalRevenue() {
		return totalRevenue;
	}
	public void setTotalRevenue(double totalRevenue) {
		this.totalRevenue = totalRevenue;
	}
	public Mall getMall() {
		return mall;
	}
	public void setMall(Mall mall) {
		this.mall = mall;
	}
	

}
