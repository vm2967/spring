package com.example.mindtree.service;

import com.example.mindtree.dto.MallDto;
import com.example.mindtree.exception.MallExistsException;

public interface MallService {

	String add(MallDto malldto) throws MallExistsException;

}
