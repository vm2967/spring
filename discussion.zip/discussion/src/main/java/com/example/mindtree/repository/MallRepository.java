package com.example.mindtree.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.mindtree.entity.Mall;

@Repository
public interface MallRepository extends JpaRepository<Mall, Integer> {

	Mall findBymallName(String mallName);
}
