package com.example.mindtree.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.mindtree.dto.ShopsDto;
import com.example.mindtree.exception.ApplicationException;

import com.example.mindtree.service.ShopService;

@RestController
public class ShopController {
	@Autowired
	ShopService shopService;
	
	
	@PostMapping(value="/addShops/{mallId}")
	public ResponseEntity<?> addShops(@PathVariable int mallId,@RequestBody ShopsDto shopdto) throws ApplicationException{
		
		String s=shopService.addShops(mallId,shopdto);
		return new ResponseEntity<String>(s, HttpStatus.ACCEPTED);
		
	}
	
	@PutMapping(value="/updateShop/{mallName}/{shopName}/{newName}")
	public ResponseEntity<?> updateShop(@PathVariable String mallName, @PathVariable String shopName,@PathVariable String newName ){
		String result=shopService.updatName(mallName,shopName,newName);
		return new ResponseEntity<String>(result, HttpStatus.ACCEPTED);
		
	}
	
	@GetMapping(value="/dispShop/{shopName}")
	public ResponseEntity<?> dispShops(@PathVariable String shopName){
		List<ShopsDto> lis=shopService.display(shopName);
		return new ResponseEntity<List<ShopsDto>>(lis, HttpStatus.ACCEPTED);
		
	}
	

}
