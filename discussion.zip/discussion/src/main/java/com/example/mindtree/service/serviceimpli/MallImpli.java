package com.example.mindtree.service.serviceimpli;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mindtree.dto.MallDto;
import com.example.mindtree.entity.Mall;
import com.example.mindtree.exception.MallExistsException;
import com.example.mindtree.repository.MallRepository;
import com.example.mindtree.service.MallService;

@Service
public class MallImpli implements MallService {

	@Autowired
	MallRepository mallRepo;
	
	@Autowired
	ModelMapper modelMapper;
	
	@Override
	public String add(MallDto malldto) throws MallExistsException {
		try {
			Mall mall=modelMapper.map(malldto, Mall.class);
		mallRepo.save(mall);
		}
		catch(Exception e) {
			throw new MallExistsException("Mall is already Exists");
			
		}
		return "mall Added Successfully";
	}

}
