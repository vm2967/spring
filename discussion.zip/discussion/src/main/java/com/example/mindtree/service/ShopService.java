package com.example.mindtree.service;

import java.util.List;

import com.example.mindtree.dto.ShopsDto;

import com.example.mindtree.exception.ServiceException;

public interface ShopService {

	String addShops(int mallId, ShopsDto shopdto) throws ServiceException;

	List<ShopsDto> display(String shopName);

	String updatName(String mallName, String shopName, String newName);

}
