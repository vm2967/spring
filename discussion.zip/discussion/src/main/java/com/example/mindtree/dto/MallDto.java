package com.example.mindtree.dto;

import java.util.List;

import com.example.mindtree.entity.Shops;

public class MallDto {
	
	private String mallName;
	private int totalShops;
	private List<Shops> shops;
	public MallDto() {
		super();

	}
	public MallDto(String mallName, int totalShops, List<Shops> shops) {
		super();
		this.mallName = mallName;
		this.totalShops = totalShops;
		this.shops = shops;
	}
	public String getMallName() {
		return mallName;
	}
	public void setMallName(String mallName) {
		this.mallName = mallName;
	}
	public int getTotalShops() {
		return totalShops;
	}
	public void setTotalShops(int totalShops) {
		this.totalShops = totalShops;
	}
	public List<Shops> getShops() {
		return shops;
	}
	public void setShops(List<Shops> shops) {
		this.shops = shops;
	}
	
	

}
