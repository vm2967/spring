package com.example.mindtree.service.serviceimpli;
import java.util.Collections;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mindtree.dto.ShopsDto;
import com.example.mindtree.entity.Mall;
import com.example.mindtree.entity.ShopComparator;
import com.example.mindtree.entity.Shops;
import com.example.mindtree.exception.MallAdditionException;
import com.example.mindtree.exception.ServiceException;
import com.example.mindtree.repository.MallRepository;
import com.example.mindtree.repository.ShopRepository;
import com.example.mindtree.service.ShopService;

@Service
public class ShopImpli implements ShopService {

	@Autowired
	ShopRepository shopRepo;
	@Autowired
	MallRepository mallRepo;
	@Autowired
	ModelMapper modelMapper;
	
	@Override
	public String addShops(int mallId, ShopsDto shopdto) throws ServiceException {
		Mall mall = mallRepo.findById(mallId).get();
		if (mall.getTotalShops()==mall.getShops().size()) {

			throw new MallAdditionException("Shop could not be added");
		} else {
			Shops shop=modelMapper.map(shopdto, Shops.class);
			shop.setMall(mall);
			shopRepo.save(shop);

		}
		return "shop added successfully";
	}

	@Override
	public List<ShopsDto> display(String shopName) {
		Shops shop=shopRepo.findByshopName(shopName);
		Mall mall=shop.getMall();
		List<Shops> shopList=mall.getShops();
		Collections.sort(shopList,new ShopComparator());
		return modelMapper.map(shopList, new TypeToken<List<ShopsDto>>() { }.getType());	
		
	}

	@Override
	public String updatName(String mallName, String shopName, String newName) {
		Mall mall=mallRepo.findBymallName(mallName);
		List<Shops> shops=mall.getShops();
		for (Shops shops2 : shops) {
			if(shops2.getShopName().equalsIgnoreCase(shopName))
			{
				shops2.setShopName(newName);
				shopRepo.save(shops2);
			}
			
		}
		return "updated Successfully";
	}
	
	
	
	

}
