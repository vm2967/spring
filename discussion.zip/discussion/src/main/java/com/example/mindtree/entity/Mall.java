package com.example.mindtree.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Mall {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int mallId;
	@Column(unique = true)
	private String mallName;
	private int totalShops;
	@OneToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL,mappedBy = "mall")
	private List<Shops> shops;

	public Mall() {
		super();
		
	}

	public Mall(int mallId, String mallName, int totalShops, List<Shops> shops) {
		super();
		this.mallId = mallId;
		this.mallName = mallName;
		this.totalShops = totalShops;
		this.shops = shops;
	}

	public int getMallId() {
		return mallId;
	}

	public void setMallId(int mallId) {
		this.mallId = mallId;
	}

	public String getMallName() {
		return mallName;
	}

	public void setMallName(String mallName) {
		this.mallName = mallName;
	}

	public int getTotalShops() {
		return totalShops;
	}

	public void setTotalShops(int totalShops) {
		this.totalShops = totalShops;
	}

	public List<Shops> getShops() {
		return shops;
	}

	public void setShops(List<Shops> shops) {
		this.shops = shops;
	}

	@Override
	public String toString() {
		return "Mall [mallId=" + mallId + ", mallName=" + mallName + ", totalShops=" + totalShops + ", shops=" + shops
				+ "]";
	}
	
	
}
