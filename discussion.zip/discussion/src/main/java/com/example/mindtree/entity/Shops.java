package com.example.mindtree.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Shops  {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int shopId;
	private String shopName;
	private double totalRevenue;
	@ManyToOne(fetch = FetchType.LAZY)
	private Mall mall;
	
	public Shops() {
		super();
		
	}
	public Shops(int shopId, String shopName, double totalRevenue, Mall mall) {
		super();
		this.shopId = shopId;
		this.shopName = shopName;
		this.totalRevenue = totalRevenue;
		this.mall = mall;
	}
	public int getShopId() {
		return shopId;
	}
	public void setShopId(int shopId) {
		this.shopId = shopId;
	}
	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public double getTotalRevenue() {
		return totalRevenue;
	}
	public void setTotalRevenue(double totalRevenue) {
		this.totalRevenue = totalRevenue;
	}
	public Mall getMall() {
		return mall;
	}
	public void setMall(Mall mall) {
		this.mall = mall;
	}
	@Override
	public String toString() {
		return "Shops [shopId=" + shopId + ", shopName=" + shopName + ", totalRevenue=" + totalRevenue + ", mall="
				+ mall + "]";
	}
	
	

}
