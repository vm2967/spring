package com.example.mindtree.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.mindtree.dto.MallDto;

import com.example.mindtree.exception.ApplicationException;
import com.example.mindtree.service.MallService;

@RestController
public class MallController {
	
	@Autowired
	MallService mallService;
	
	@PostMapping(value="/addMall")
	public ResponseEntity<?> addMall(@RequestBody MallDto malldto) throws ApplicationException{
		String m=mallService.add(malldto);
		return new ResponseEntity<String>(m, HttpStatus.ACCEPTED);
		
	}
	
	

}
