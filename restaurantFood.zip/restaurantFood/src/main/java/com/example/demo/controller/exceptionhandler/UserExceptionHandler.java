package com.example.demo.controller.exceptionhandler;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;

import com.example.demo.exception.ApplicationException;

@ControllerAdvice
public class UserExceptionHandler {
	
	@ExceptionHandler(ApplicationException.class)
	@ResponseStatus(value = HttpStatus.CONFLICT)
	public final String handleUserAlreadyBookedException(ApplicationException ex, WebRequest request)
	{
		return "UserNotFoundException";
	}

}
