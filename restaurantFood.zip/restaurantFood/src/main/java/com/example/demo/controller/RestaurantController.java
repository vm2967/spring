package com.example.demo.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.entity.ItemDto;
import com.example.demo.entity.Items;
import com.example.demo.entity.User;
import com.example.demo.exception.ApplicationException;
import com.example.demo.serviceInterface.ItemsInterface;
import com.example.demo.serviceInterface.UserInterface;

@Controller
public class RestaurantController {

	@Autowired
	UserInterface userService;
	
	@Autowired
	ItemsInterface itemservice;
	
	public static User foradduser;
	

	@RequestMapping("/")
	public String homePage() {
		return "homepage";
	}

	@RequestMapping("/addUser")
	public String LoginPage(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		return "addUser";
	}
	@RequestMapping(value = "/saveUser", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute("user") User user, Model model) throws ApplicationException {
		foradduser = user;
		boolean flag = userService.addUser(user);
		if (flag == true) {

			model.addAttribute("foradduser", foradduser);
			return "startcreateitem";
		}
		return "redirect:/";
	}
	@RequestMapping("/CreateItem")
	public String CreateItem(Model model) {
		String name=foradduser.getUserName();
		Items item = new Items();
		model.addAttribute("name", name);
		model.addAttribute("item", item);
		return "createitem";
	}
	@RequestMapping(value = "/saveitem", method = RequestMethod.POST)
	public String saveItems(@ModelAttribute("item") Items item) {
		itemservice.addItems(item, foradduser);
		return  "startcreateitem";

	}
	
	
	@RequestMapping(value="/givequantity",method = RequestMethod.GET)
	public ModelAndView giveQuantity(Model model) {
		String name=foradduser.getUserName();
		List<Items>	userItems=itemservice.showVegItemList();
		ItemDto itemdto=new ItemDto();
		itemdto.setListContainer(userItems);
		//user1.setUserItems(userItems);
		model.addAttribute("name", name);
		return new ModelAndView("quantityPage","itemdto",itemdto);
		
	}
	
	@RequestMapping(value="/saveVeg",method =RequestMethod.POST )
	public String saveVeg(@ModelAttribute("itemdto") ItemDto itemdto) {
		List<Items> userItems=itemdto.getListContainer();
		itemservice.updateRatings(userItems);
		return "startcreateitem";
		
	}
	
	@RequestMapping(value="/givequantityNonVeg",method = RequestMethod.GET)
	public ModelAndView giveQuantityNonVeg(Model model) {
		String name=foradduser.getUserName();
		List<Items>	userItems=itemservice.showNonVegItemList();
		ItemDto itemdto=new ItemDto();
		itemdto.setListContainer(userItems);
		//user1.setUserItems(userItems);
		model.addAttribute("name", name);
		return new ModelAndView("quantityPage","itemdto",itemdto);
	}
	
//	@RequestMapping("/vegitemlist")
//	public String vegItemList(Model model) {
//		String name=foradduser.getUserName();
//		List<Items> listByTypeVeg=itemservice.showVegItemList();
//		model.addAttribute("name", name);
//		model.addAttribute("listByTypeVeg", listByTypeVeg);
//		return "vegItemPage";
//		
//	}
//	@RequestMapping("/nonveglist")
//	public String nonVegList(Model model) {
//		String name=foradduser.getUserName();
//		List<Items> listByTypeNonVeg=itemservice.showNonVegItemList();
//		model.addAttribute("name", name);
//		model.addAttribute("listByTypeNonVeg", listByTypeNonVeg);
//		return "nonVegItemPage";
//		
//	}
	
	@RequestMapping(value="/giverating",method = RequestMethod.GET)
	public ModelAndView giveRating(Model model) {
		String name=foradduser.getUserName();
		List<Items>	userItems=itemservice.getAllItemsList();
		ItemDto itemdto=new ItemDto();
		itemdto.setListContainer(userItems);
		model.addAttribute("name", name);
		return new ModelAndView("ratingpage","itemdto",itemdto);
	}
	
	@RequestMapping(value="/saveRating",method = RequestMethod.POST)
	public String saveRating(@ModelAttribute("itemdto") ItemDto itemdto) {
		List<Items> userItems=itemdto.getListContainer();
		//List<Items>	userItems=items.stream().filter(t->t.getRating()!=0.0).collect(Collectors.toList());
		itemservice.updateRatings(userItems);
		return "startcreateitem";
		
	}
	
//	@RequestMapping(value = "/giveRatingsPage")
//	public String goToRatingsPage(Model model) {
//		String name=foradduser.getUserName();
//		model.addAttribute("name", name);
//		List<Items> getItemsList = itemservice.getAllItemsList();
//		model.addAttribute("getItemsList", getItemsList);
//		return "giveRatingsPage";
//	} 
//	@RequestMapping(value = "/addRatings")
//	public String addRatings(HttpServletRequest request) {
//		String[] getSelectedItemsList = request.getParameterValues("itemName");
//		String[] getAllRatings = request.getParameterValues("rating");
//		itemservice.addRatings(getSelectedItemsList, getAllRatings);
//		return "startcreateitem";
//	}
	
	@RequestMapping(value="/totalCost",method = RequestMethod.GET)
	public String ShowTotalCost(Model model) {
		String name=foradduser.getUserName();
		List<Items> listCostforItems=itemservice.getAllItemsList();
		double sum=itemservice.getTotalCost();
		model.addAttribute("sum", sum);
		model.addAttribute("listCostforItems", listCostforItems);
		model.addAttribute("name", name);
		return "totalcost";
		
	}

}
