package com.example.demo.serviceInterface.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.controller.RestaurantController;
import com.example.demo.entity.Items;
import com.example.demo.entity.User;
import com.example.demo.exception.ServiceException;
import com.example.demo.exception.UserNameNotFoundException;
import com.example.demo.repository.UserRepository;
import com.example.demo.serviceInterface.UserInterface;

@Service
public class UserService implements UserInterface {

	@Autowired
	UserRepository userRepo;

	@Override
	public boolean addUser(User user) throws ServiceException {

		List<User> userList = userRepo.findAll();
		boolean flag = false;
		for (User user2 : userList) {

			if (user2.getUserName().equals(user.getUserName())
					&& user2.getUserPassword().equals(user.getUserPassword())) {
				flag = true;
			}
		}
		if (flag == false) {
			throw new UserNameNotFoundException();
		}
		return flag;

	}

//	@Override
//	public void saveUpdated(User user1) {
//		User user2=userRepo.findByUserName(RestaurantController.foradduser.getUserName());
//		//user2.setUserItems(user1.getUserItems());
//		//System.out.println(user2.getUserId());
//		user1.setUserId(user2.getUserId());
//		user1.setUserName(user2.getUserName());
//		user1.setUserPassword(user2.getUserPassword());
//		user1.setUserPassword2(user2.getUserPassword2());
//		userRepo.save(user2);
//		
//	}

	

	

}
