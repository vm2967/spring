package com.example.demo.serviceInterface.service;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.controller.RestaurantController;
import com.example.demo.entity.Items;
import com.example.demo.entity.User;
import com.example.demo.repository.ItemsRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.serviceInterface.ItemsInterface;

@Service
public class ItemsService implements ItemsInterface {
	
	
	@Autowired
	ItemsRepository itemRepo;
	
	@Autowired
	UserRepository userRepo;

	@Override
	public void addItems(Items item, User foradduser) {
		User user = userRepo.findByUserName(foradduser.getUserName());
		item.setUser(user);
		itemRepo.save(item);
	}
	
	@Override
	public List<Items> showVegItemList() {
		User user = userRepo.findByUserName(RestaurantController.foradduser.getUserName());
		List<Items> getAllItemsList = itemRepo.findAll();
		List<Items> getAllItemsListByUserName = getAllItemsList.stream()
				.filter(t -> t.getUser().getUserId() == user.getUserId()).collect(Collectors.toList());
		List<Items> listBytype=getAllItemsListByUserName.stream().filter(p->p.getItemType().equals("Veg")).collect(Collectors.toList());
		return listBytype;
	}

	@Override
	public List<Items> showNonVegItemList() {
		User user = userRepo.findByUserName(RestaurantController.foradduser.getUserName());
		List<Items> getAllItemsList = itemRepo.findAll();
		List<Items> getAllItemsListByUserName = getAllItemsList.stream()
				.filter(t -> t.getUser().getUserId() == user.getUserId()).collect(Collectors.toList());
		List<Items> listByNonVegtype=getAllItemsListByUserName.stream().filter(p->p.getItemType().equals("Non-Veg")).collect(Collectors.toList());
		return listByNonVegtype;
	}
	@Override
	public List<Items> getAllItemsList() {
		User user = userRepo.findByUserName(RestaurantController.foradduser.getUserName());
		List<Items> allItemsList=itemRepo.findAll();
		List<Items> getAllItemsListByUserName = allItemsList.stream()
				.filter(t -> t.getUser().getUserId() == user.getUserId()).collect(Collectors.toList());
		return getAllItemsListByUserName;
	}
	
//	@Override
//	public void addRatings(String[] getSelectedItemsList, String[] getAllRatings) {
//		int x = 0;
//		String arr[] = new String[getAllRatings.length];
//		for (int l = 0; l < getAllRatings.length; l++) {
//			if (getAllRatings[l].equals("0.0")) {
//				continue;
//			} else {
//				arr[x] = getAllRatings[l];
//				x++;
//			}
//		}
//		int k = 0;
//		for (int i = 0; i < getSelectedItemsList.length; i++) {
//			Items items = itemRepo.findByItemName(getSelectedItemsList[i]);
//			for (int j = k; j < x; j++) {
//				if (arr[j] != "0.0") {
//					items.setRating(Double.parseDouble(arr[j]));
//					k++;
//					break;
//				}
//			}
//			itemRepo.save(items);
//		}
//	}
	
	@Override
	public double getTotalCost() {
		User user=userRepo.findByUserName(RestaurantController.foradduser.getUserName());
		List<Items> allItemsList=itemRepo.findAll();
		double sum=allItemsList.stream().filter(t->t.getUser().getUserId()==user.getUserId()).mapToDouble(d->d.getItemPrice()*d.getItemQuantity()).reduce(0,(a,b)->a+b);
		return sum;
	}
	@Override
	public void updateRatings(List<Items> userItems) {
		User user=userRepo.findByUserName(RestaurantController.foradduser.getUserName());
		//user.setUserItems(userItems);
		for (Items items : userItems) {
			items.setUser(user);
			itemRepo.save(items);
		}

	}
	

}
