package com.example.demo.entity;

import java.util.List;

public class ItemDto {

  private List<Items> listContainer;

public List<Items> getListContainer() {
	return listContainer;
}

public void setListContainer(List<Items> listContainer) {
	this.listContainer = listContainer;
}
  
  
}
