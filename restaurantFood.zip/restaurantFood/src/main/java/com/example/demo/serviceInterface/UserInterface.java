package com.example.demo.serviceInterface;






import com.example.demo.entity.User;
import com.example.demo.exception.ServiceException;


public interface UserInterface {

	boolean addUser(User user) throws ServiceException;

	

	//void saveUpdated(User user1);
}
