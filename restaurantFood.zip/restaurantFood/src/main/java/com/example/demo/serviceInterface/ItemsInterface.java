package com.example.demo.serviceInterface;

import java.util.List;

import com.example.demo.entity.Items;
import com.example.demo.entity.User;

public interface ItemsInterface {

	void addItems(Items item,  User foradduser);

	List<Items> showVegItemList();

	List<Items> showNonVegItemList();

	List<Items> getAllItemsList();

	//void addRatings(String[] getSelectedItemsList, String[] getAllRatings);

	double getTotalCost();

	void updateRatings(List<Items> userItems);

}
