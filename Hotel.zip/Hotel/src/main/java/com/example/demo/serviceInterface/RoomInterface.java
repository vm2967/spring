package com.example.demo.serviceInterface;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Room;
import com.example.demo.exception.ServiceException;


@Service

public interface RoomInterface {


	String addOnlyRoom(Room room);

	String addR(int hotelId, int roomId) throws ServiceException;

}
