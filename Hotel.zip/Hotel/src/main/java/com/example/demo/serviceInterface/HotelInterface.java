package com.example.demo.serviceInterface;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Hotel;
import com.example.demo.entity.Room;
import com.example.demo.exception.ServiceException;

@Service

public interface HotelInterface {

	String add(Hotel hotel);

	List<Room> getAllRoom(int hotelId) throws ServiceException;

	List<Hotel> sortHotel();

}
