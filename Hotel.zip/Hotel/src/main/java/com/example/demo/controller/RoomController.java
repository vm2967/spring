package com.example.demo.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entity.Room;
import com.example.demo.exception.ApplicationException;
import com.example.demo.exception.ServiceException;
import com.example.demo.serviceInterface.HotelInterface;
import com.example.demo.serviceInterface.RoomInterface;

@RestController
public class RoomController {
	@Autowired
	HotelInterface hotelInterface;
	@Autowired
	RoomInterface roomInterface;
	
	
	@PostMapping(value="/addRooms")
	public ResponseEntity<?>addingRoom(@RequestBody Room room )
	{
		String r=roomInterface.addOnlyRoom(room);
		return new ResponseEntity<String>(r, HttpStatus.ACCEPTED);
		
	}
	
	@PutMapping(value="/addRoom/{hotelId}/{roomId}")
	public ResponseEntity<String> addRoom(@PathVariable int hotelId, @PathVariable int roomId) throws ApplicationException {
		String ro;
		try {
			ro = roomInterface.addR(hotelId, roomId);
		} catch (ServiceException e) {
			
			throw new ApplicationException(e.getMessage(),e);
		}
			return new ResponseEntity<String>(ro, HttpStatus.ACCEPTED);
			
		
	}
	
	
	 
	

}
