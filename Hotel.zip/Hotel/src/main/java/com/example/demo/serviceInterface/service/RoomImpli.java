package com.example.demo.serviceInterface.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.Hotel;
import com.example.demo.entity.Room;
import com.example.demo.exception.HotelNotFoundException;
import com.example.demo.exception.ServiceException;
import com.example.demo.repository.HotelRepository;
import com.example.demo.repository.RoomRepository;
import com.example.demo.serviceInterface.RoomInterface;
@Service
public class RoomImpli implements RoomInterface {
	@Autowired
	HotelRepository hotelRepo;
	
	@Autowired
	RoomRepository roomRepo;

	@Override
	public String addOnlyRoom(Room room) {
		if(room.getRoomType().equalsIgnoreCase("luxury")||room.getRoomType().equalsIgnoreCase("single")||room.getRoomType().equalsIgnoreCase("double"))
		{roomRepo.save(room);
		return "Room Added Successfully";
		}
		else
		{
			return"Room Type is not Correct";
		}
		
	}

	@Override
	public String addR(int hotelId, int roomId) throws ServiceException {
		Hotel hotel;
		try {
			hotel = hotelRepo.findById(hotelId).orElseThrow(()->new HotelNotFoundException("For this Id Hotel is Not Present"));
			Room room=roomRepo.findById(roomId).orElse(null);
			hotel.getRoom().add(room);
			room.setHotel(hotel);
			roomRepo.save(room);
			hotelRepo.save(hotel);
			return "Room Assigned Successfully";
		} catch (HotelNotFoundException e) {
			
			throw new ServiceException(e.getMessage(),e);
		}
		
	}

}
