package com.example.demo.serviceInterface.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.Hotel;
import com.example.demo.entity.HotelComparator;
import com.example.demo.entity.Room;
import com.example.demo.repository.HotelRepository;
import com.example.demo.serviceInterface.HotelInterface;

@Service

public class HotelImpli implements HotelInterface {
	@Autowired
	HotelRepository hotelRepo;

	@Override
	public String add(Hotel hotel) {
		hotelRepo.save(hotel);

		return "Hotel Added Successfully";
	}

	@Override
	public List<Room> getAllRoom(int hotelId) {
		Hotel hotel;
		List<Room> li = new ArrayList<>();
		
			hotel = hotelRepo.findById(hotelId).orElse(null);
			for (Room room : hotel.getRoom()) {
				if (room.getPricePerDay() > 2500) {
					li.add(room);
				}

			}
			return li;
	}

	@Override
	public List<Hotel> sortHotel() {
		List<Hotel> li = hotelRepo.findAll();
		Collections.sort(li, new HotelComparator());
		return li;
	}

}
