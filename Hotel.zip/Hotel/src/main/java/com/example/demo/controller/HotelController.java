package com.example.demo.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entity.Hotel;
import com.example.demo.entity.Room;
import com.example.demo.exception.ApplicationException;
import com.example.demo.serviceInterface.HotelInterface;

@RestController

public class HotelController {
	
	@Autowired
	HotelInterface hotelInterface;
	

	@PostMapping(value = "/add")
	public ResponseEntity<?> addHotel(@RequestBody Hotel hotel) {

		String ho = hotelInterface.add(hotel);
		return new ResponseEntity<String>(ho, HttpStatus.ACCEPTED);

	}
	
	
	
	@GetMapping(value = "/getRoom/{hotelId}")
	public ResponseEntity<?> getRooms(@PathVariable int hotelId) throws ApplicationException {
		List<Room> hotel=null;
		
			hotel = hotelInterface.getAllRoom(hotelId);
			
		return new ResponseEntity<List<Room>>(hotel, HttpStatus.FOUND);	

	}
	
	@GetMapping(value = "/getAllHotels")
	public ResponseEntity<?> sortHotels() {
		List<Hotel> lis = hotelInterface.sortHotel();
		return new ResponseEntity<List<Hotel>>(lis, HttpStatus.FOUND);

	}

}
