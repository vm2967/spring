package com.example.demo.entity;

import java.util.Comparator;

public class HotelComparator implements Comparator<Hotel>{

	@Override
	public int compare(Hotel arg0, Hotel arg1) {
		int result= arg0.getHotelLocation().compareTo(arg1.getHotelLocation() ) ;
		 if(result!=0) {
			 return result;
			 
		 }
		 else {
			 return arg0.getHotelRating()-arg1.getHotelRating();
		 }
		
	}

}
