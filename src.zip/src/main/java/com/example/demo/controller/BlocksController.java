package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Blocks;
import com.example.demo.serviceInterface.BlocksInterface;

@RestController
public class BlocksController {
	
	@Autowired
	BlocksInterface blockService;
	
	@PostMapping(value="/addBlock")
	public ResponseEntity<?> addBlock(@RequestBody Blocks blocks){
		String bo=blockService.add(blocks);
		return new ResponseEntity<String>(bo,HttpStatus.ACCEPTED);
		
	}
	
	@GetMapping(value="/getAllByBlock/{blockId}")
	public ResponseEntity<?> getAllShops(@PathVariable int blockId){
		
		Blocks blocks=blockService.getByBlockId(blockId);
		
		return new ResponseEntity<Blocks>(blocks, HttpStatus.FOUND);
		
	}
	
	
	
	
	

}
