package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Dishes;
import com.example.demo.serviceInterface.DishesInterface;

@RestController
public class DishesController {
	
@Autowired
DishesInterface dishService;


@PostMapping(value="/addDish/{shopId}")
public ResponseEntity<?> addDishes(@PathVariable int shopId,@RequestBody Dishes dish){
	String so=dishService.addDish(shopId,dish);
	return new ResponseEntity<String>(so, HttpStatus.ACCEPTED);
	
}

}
