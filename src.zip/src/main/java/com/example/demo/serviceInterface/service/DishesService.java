package com.example.demo.serviceInterface.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Dishes;
import com.example.demo.entity.Shops;
import com.example.demo.repository.DishesRepository;
import com.example.demo.repository.ShopsRepository;
import com.example.demo.serviceInterface.DishesInterface;

@Service
public class DishesService implements DishesInterface {

	@Autowired
	DishesRepository dishRepo;

	@Autowired
	ShopsRepository shopRepo;

	@Override
	public String addDish(int shopId, Dishes dish) {

		Shops shops = shopRepo.findById(shopId).orElse(null);

		dish.setShop(shops);
		if (dish.getShop().getRating() > 4.5) {

			dish.setDishPrice(dish.getDishPrice() - (dish.getDishPrice() * 10 / 100));

		} else if (dish.getShop().getRating() > 3.5) {
			dish.setDishPrice(dish.getDishPrice() - (dish.getDishPrice() * 5 / 100));

		} else if (dish.getShop().getRating() > 2.5) {
			dish.setDishPrice(dish.getDishPrice() - (dish.getDishPrice() * 2 / 100));

		}
		dishRepo.save(dish);
		return "dishAddedSuccessfully";
	}

}
