package com.example.demo.serviceInterface;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Dishes;
import com.example.demo.entity.Shops;

@Service
public interface ShopsInterface {

	String addShops(int blockId, Shops shops);

	List<Shops> getAllShopsByType(String shopType);

	List<Dishes> getDishesByShopId(int shopId);

	List<Dishes> getDishesInDesc(int shopId);

}
