package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KalingashopApplication {

	public static void main(String[] args) {
		SpringApplication.run(KalingashopApplication.class, args);
	}

}
