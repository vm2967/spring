package com.example.demo;

import static org.junit.Assert.*;

import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.Blocks;
import com.example.demo.repository.BlocksRepository;
import com.example.demo.serviceInterface.service.BlocksService;


@SpringBootTest
@RunWith(MockitoJUnitRunner.Silent.class)
public class BlockServiceTest {
	@InjectMocks
	private BlocksService blockService;
	
	@Mock
	private BlocksRepository blockRepo;
	
	private Blocks block=new Blocks();
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		
	}
	
	@Test
	public void addBlock_Test() {
		block.setBlockId(1);
		block.setBlockName("Amla");
		when(blockRepo.save(block)).thenReturn(block);
		assertEquals("blockAddedSuccessfully", blockService.add(block));
	}
	
	@Test
	public void getBlockById_Test() {
		block.setBlockId(1);
		block.setBlockName("Amla");
		when(blockRepo.findById(1)).thenReturn(Optional.of(block));
		assertEquals(block, blockService.getByBlockId(block.getBlockId()));
		
	}

	

}
