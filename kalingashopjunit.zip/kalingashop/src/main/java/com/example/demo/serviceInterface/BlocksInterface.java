package com.example.demo.serviceInterface;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Blocks;

@Service
public interface BlocksInterface {

	String add(Blocks blocks);

	Blocks getByBlockId(int blockId);

}
