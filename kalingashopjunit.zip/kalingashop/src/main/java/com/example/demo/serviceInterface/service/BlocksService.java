package com.example.demo.serviceInterface.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Blocks;
import com.example.demo.repository.BlocksRepository;
import com.example.demo.serviceInterface.BlocksInterface;

@Service
public class BlocksService implements BlocksInterface{

	@Autowired
	BlocksRepository blockRepo;
	
	@Override
	public String add(Blocks blocks) {
		blockRepo.save(blocks);
		return "blockAddedSuccessfully";
	}

	@Override
	public Blocks getByBlockId(int blockId) {
		Blocks block=blockRepo.findById(blockId).get();
		return block;
	}
	


}
