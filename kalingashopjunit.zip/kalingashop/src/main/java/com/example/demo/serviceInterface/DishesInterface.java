package com.example.demo.serviceInterface;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Dishes;

@Service
public interface DishesInterface {

	String addDish(int shopId, Dishes dish);

}
