package com.example.demo.serviceInterface.service;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Blocks;
import com.example.demo.entity.Dishes;
import com.example.demo.entity.Shops;
import com.example.demo.repository.BlocksRepository;
import com.example.demo.repository.ShopsRepository;
import com.example.demo.serviceInterface.ShopsInterface;

@Service
public class ShopsService implements ShopsInterface{
	
	@Autowired
	ShopsRepository shopRepo;
	
	@Autowired
	
	BlocksRepository blockRepo;
	

	@Override
	public String addShops(int blockId, Shops shops) {
		Blocks blocks=blockRepo.findById(blockId).orElse(null);
		
		shops.setBlock(blocks);
		shopRepo.save(shops);
		
		return "shopAddedSuccessfully";
	}


	@Override
	public List<Shops> getAllShopsByType(String shopType) {
		return shopRepo.findByShopType(shopType);
	}


	@Override
	public List<Dishes> getDishesByShopId(int shopId) {
		
	Shops shops=shopRepo.findById(shopId).orElse(null);
	
	List<Dishes> listDishes=shops.getShopdishes().stream().sorted(Comparator.comparingDouble(Dishes::getDishPrice)).collect(Collectors.toList());
	
		return listDishes;
	}


	@Override
	public List<Dishes> getDishesInDesc(int shopId) {
		Shops shop=shopRepo.findById(shopId).get();
		
		List<Dishes> listDishes=shop.getShopdishes().stream().sorted(Comparator.comparingDouble(Dishes::getDishPrice).reversed()).collect(Collectors.toList());
		return listDishes;
	}

}
