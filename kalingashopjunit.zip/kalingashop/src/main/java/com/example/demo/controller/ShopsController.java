package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Dishes;
import com.example.demo.entity.Shops;
import com.example.demo.serviceInterface.ShopsInterface;

@RestController
public class ShopsController {

	@Autowired
	ShopsInterface shopService;

	@PostMapping(value = "/addShop/{blockId}")
	public ResponseEntity<?> addShop(@PathVariable int blockId, @RequestBody Shops shops) {
		String so = shopService.addShops(blockId, shops);

		return new ResponseEntity<String>(so, HttpStatus.ACCEPTED);

	}

	@GetMapping(value = "/getAllTypeShop/{shopType}")
	public ResponseEntity<?> getShopsByType(@PathVariable String shopType) {

		List<Shops> listShops = shopService.getAllShopsByType(shopType);

		return new ResponseEntity<List<Shops>>(listShops, HttpStatus.FOUND);

	}
	
	@GetMapping(value="/getDishesByShop/{shopId}")
	public ResponseEntity<?> getDishesByShop(@PathVariable int shopId){
		
		List<Dishes> listDishes=shopService.getDishesByShopId(shopId);
		return new ResponseEntity<List<Dishes>>(listDishes, HttpStatus.FOUND);
		
	}
	
	@GetMapping(value="/getDishesInDesc/{shopId}")
	public ResponseEntity<?> getDishesInDescding(@PathVariable int shopId){
		
		List<Dishes> dishesList=shopService.getDishesInDesc(shopId);
		return new ResponseEntity<List<Dishes>>(dishesList, HttpStatus.FOUND);
		
	}

}
