package com.example.demo;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;


import com.example.demo.entity.Blocks;
import com.example.demo.entity.Dishes;
import com.example.demo.entity.Shops;
import com.example.demo.repository.BlocksRepository;
import com.example.demo.repository.ShopsRepository;
import com.example.demo.serviceInterface.service.ShopsService;
@SpringBootTest
@RunWith(MockitoJUnitRunner.Silent.class)
public class ShopsServiceTest {

	@InjectMocks
	private ShopsService shopservice;
	
	@Mock
	private ShopsRepository shopRepo;
	
	@Mock
	private BlocksRepository blockRepo;
	
	private Blocks block=new Blocks();
	private Shops shop=new Shops();
	private List<Shops>shoplist=new ArrayList<Shops>();
	private List<Dishes>dishlist=new ArrayList<Dishes>();
	private Dishes dishes=new Dishes();
	
	
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		block.setBlockId(1);
		block.setBlockName("Amla");
		shop.setShopId(2);
		shop.setShopName("Foodie");
		shop.setShopType("veg");
		shop.setRating(4.3f);
		shoplist.add(shop);
		
	}
	
	@Test
	public void addShop_Test() {	
		
	    when(blockRepo.findById(1)).thenReturn(Optional.of(block));
		shop.setBlock(block);
		when(shopRepo.save(shop)).thenReturn(shop);
		assertEquals("shopAddedSuccessfully", shopservice.addShops(block.getBlockId(), shop));
		
	}
	
	@Test
	public void displayShopsByShopType_Test() {
		when(shopRepo.findAllByShopType("veg")).thenReturn(shoplist);
		
		assertEquals(shoplist,shopservice.getAllShopsByType(shop.getShopType()));	
		
	}
	@Test
	public void getDishesByShopId_Test() {
		shop.setShopId(2);
		shop.setShopName("Foodie");
		shop.setShopType("veg");
		shop.setRating(4.3f);
		dishes.setDishId(1);
		dishes.setDishName("Pasta");
		dishes.setDishPrice(400);
		dishes.setDishType("spicy");
		dishes.setShop(shop);
		dishlist.add(dishes);
		shop.setShopdishes(dishlist);
		
		when(shopRepo.findById(2)).thenReturn(Optional.of(shop));
		assertEquals(shop.getShopdishes(), shopservice.getDishesByShopId(shop.getShopId()));
		
		
	}
	

}
