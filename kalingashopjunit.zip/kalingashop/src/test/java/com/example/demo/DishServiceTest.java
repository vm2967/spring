package com.example.demo;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.Dishes;
import com.example.demo.entity.Shops;
import com.example.demo.repository.DishesRepository;
import com.example.demo.repository.ShopsRepository;
import com.example.demo.serviceInterface.service.DishesService;

@SpringBootTest
@RunWith(MockitoJUnitRunner.Silent.class)
public class DishServiceTest {

	@InjectMocks
	DishesService dishService;
	
	@Mock
	DishesRepository dishRepo;
	
	@Mock
	ShopsRepository shopRepo;
	
	private Shops shop=new Shops();
	private Dishes dishes=new Dishes();
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		shop.setShopId(2);
		shop.setShopName("Foodie");
		shop.setShopType("veg");
		shop.setRating(4.6f);
		
		
		
	}
	
	@Test
	public void addDish_Test() {
		dishes.setDishId(1);
		dishes.setDishName("Pasta");
		dishes.setDishPrice(400);
		dishes.setDishType("spicy");
		when(shopRepo.findById(2)).thenReturn(Optional.of(shop));
		dishes.setShop(shop);
		
		when(dishRepo.save(dishes)).thenReturn(dishes);
		assertEquals("dishAddedSuccessfully", dishService.addDish(shop.getShopId(), dishes));
		
	}
	
	
}
