package com.example.demo.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Booking {
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	private int bookingId;
	private Date datefrom;
	private Date dateto;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	private Room room;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	private Hotel hotel;
	
	@ManyToOne(fetch =FetchType.LAZY )
	@JsonIgnore
	private User user;

	public Booking() {
		super();
		
	}

	public Booking(int bookingId, Date datefrom, Date dateto, Room room, Hotel hotel, User user) {
		super();
		this.bookingId = bookingId;
		this.datefrom = datefrom;
		this.dateto = dateto;
		this.room = room;
		this.hotel = hotel;
		this.user = user;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public Date getDatefrom() {
		return datefrom;
	}

	public void setDatefrom(Date datefrom) {
		this.datefrom = datefrom;
	}

	public Date getDateto() {
		return dateto;
	}

	public void setDateto(Date dateto) {
		this.dateto = dateto;
	}

	public Room getRoom() {
		return room;
	}


	public void setRoom(Room room) {
		this.room = room;
	}

	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", datefrom=" + datefrom + ", dateto=" + dateto + ", room=" + room
				+ ", hotel=" + hotel + ", user=" + user + "]";
	}

	
	
	
	
	
	
	

}
