package com.example.demo.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Hotel {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int hotelId;
	private String hotelName;
	@OneToMany(fetch = FetchType.EAGER,mappedBy = "hotel",cascade = CascadeType.ALL)
	private List<Room> room;
	
	@OneToMany(cascade = CascadeType.ALL,mappedBy = "hotel")
	private List<Booking> booking;

	public Hotel() {
		super();
		
	}

	public Hotel(int hotelId, String hotelName, List<Room> room, List<Booking> booking) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.room = room;
		this.booking = booking;
	}

	public int getHotelId() {
		return hotelId;
	}

	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public List<Room> getRoom() {
		return room;
	}

	public void setRoom(List<Room> room) {
		this.room = room;
	}

	public List<Booking> getBooking() {
		return booking;
	}

	public void setBooking(List<Booking> booking) {
		this.booking = booking;
	}

	@Override
	public String toString() {
		return "Hotel [hotelId=" + hotelId + ", hotelName=" + hotelName + ", room=" + room + ", booking=" + booking
				+ "]";
	}
	
	
	

}
