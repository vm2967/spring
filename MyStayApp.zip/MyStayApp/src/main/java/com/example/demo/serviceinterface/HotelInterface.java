package com.example.demo.serviceinterface;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Hotel;
@Service
public interface HotelInterface {

	void saveHotel(Hotel hotel);

	List<Hotel> getHotelList();
	

}
