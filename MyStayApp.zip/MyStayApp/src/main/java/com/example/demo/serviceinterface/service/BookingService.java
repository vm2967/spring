package com.example.demo.serviceinterface.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Booking;
import com.example.demo.repository.BookingRepository;
import com.example.demo.serviceinterface.BookingInterface;

@Service

public class BookingService implements BookingInterface {

	@Autowired
	BookingRepository bookingRepo;

	@Override
	public List<Booking> listOfBooking() {

		return bookingRepo.findAll();
	}

	@Override
	public void saveBooking(Booking booking) {
		
		bookingRepo.save(booking);

	}

	@Override
	public List<Booking> getAllBookingDetails() {

		return bookingRepo.findAll();

	}

}
