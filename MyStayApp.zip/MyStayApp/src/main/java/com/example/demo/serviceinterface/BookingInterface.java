package com.example.demo.serviceinterface;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Booking;

@Service

public interface BookingInterface {

	List<Booking> listOfBooking();

	void saveBooking(Booking booking);

	List<Booking> getAllBookingDetails();

}
