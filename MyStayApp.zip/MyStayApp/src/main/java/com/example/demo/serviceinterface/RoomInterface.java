package com.example.demo.serviceinterface;

import org.springframework.stereotype.Service;

@Service

public interface RoomInterface {

}
