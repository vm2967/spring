package com.example.demo.serviceinterface;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.User;
@Service
public interface UserInterface {

	void saveUser(User user);

	List<User> getUserList();

}
