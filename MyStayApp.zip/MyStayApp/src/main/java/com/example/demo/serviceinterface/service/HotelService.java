package com.example.demo.serviceinterface.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.Hotel;
import com.example.demo.repository.HotelRepository;
import com.example.demo.serviceinterface.HotelInterface;
@Service

public class HotelService implements HotelInterface {
	@Autowired
	HotelRepository hotelRepo;

	@Override
	public void saveHotel(Hotel hotel) {
		hotelRepo.save(hotel);
		
	}

	@Override
	public List<Hotel> getHotelList() {
		
		return hotelRepo.findAll();
	}

}
