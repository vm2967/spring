package com.example.demo.controller;

import java.util.ArrayList;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.entity.Booking;
import com.example.demo.entity.Hotel;
import com.example.demo.entity.Room;
import com.example.demo.entity.User;
import com.example.demo.exception.UserAlreadyBookedException;
import com.example.demo.serviceinterface.BookingInterface;
import com.example.demo.serviceinterface.HotelInterface;
import com.example.demo.serviceinterface.UserInterface;

@Controller

public class MyStayController {
	@Autowired
	UserInterface userService;
	@Autowired
	HotelInterface hotelService;
	@Autowired
	BookingInterface bookingService;

	@RequestMapping("/")
	public String homepage() {
		return "homepage";
	}

	@RequestMapping("/adduser")
	public String addUser(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		return "adduser";

	}

	@RequestMapping(value = "/saveuser", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute("user") User user) {
		userService.saveUser(user);
		return "redirect:/adduser";

	}

	@RequestMapping("/addhotel")
	public String addHotel(Model model) {
		Hotel hotel = new Hotel();
		model.addAttribute("hotel", hotel);
		return "addhotel";
	}

	@RequestMapping(value = "/savehotel", method = RequestMethod.POST)
	public String saveHotel(@ModelAttribute("hotel") Hotel hotel) {
		hotelService.saveHotel(hotel);
		return "redirect:/addhotel";

	}

	User foradduser;
	Hotel foraddhotel;

	@RequestMapping("/booking")
	public String booking(Model model) {
		List<User> userlistfordropdown = userService.getUserList();
		
		model.addAttribute("userlistfordropdown", userlistfordropdown);

		List<Hotel> hotellistfordropdown = hotelService.getHotelList();
		model.addAttribute("hotellistfordropdown", hotellistfordropdown);

		Booking booking = new Booking();
		model.addAttribute("booking", booking);
		return "booking";
	}

	@RequestMapping(value = "/chooseroom", method = RequestMethod.GET)
	public String chooseRoomAndDate(Model model, @ModelAttribute("booking") Booking booking) {

		List<Room> listOfRoomToShow = booking.getHotel().getRoom();

		foraddhotel = booking.getHotel();
		foradduser = booking.getUser();
		model.addAttribute("listOfRoomToShow", listOfRoomToShow);
		model.addAttribute("booking", booking);
		return "chooseroom";
		
	}

	@RequestMapping(value = "/savebooking", method = RequestMethod.POST)
	public String saveBooking(@ModelAttribute("booking") Booking booking) throws UserAlreadyBookedException {
		List<Booking> bookinglist = bookingService.listOfBooking();
		for (Booking booking2 : bookinglist) {
			if (booking2.getDatefrom().equals(booking.getDatefrom())) {
				
				
				throw new UserAlreadyBookedException();

			}

		}
		booking.setUser(foradduser);
		booking.setHotel(foraddhotel);
		bookingService.saveBooking(booking);
		return "paymentsuccess";

	}

	@RequestMapping("/history")
	public String bookingHistory(Model model) {
		List<User> userlistfordropdown = userService.getUserList();
		model.addAttribute("userlistfordropdown", userlistfordropdown);

		User user = new User();
		model.addAttribute("user", user);

		return "processhistory";

	}

	@RequestMapping(value = "/showhistory", method = RequestMethod.POST)
	public String showBookingHistory(Model model, @ModelAttribute("user") User user) {

		List<Booking> listOfBookings = bookingService.listOfBooking();
		List<Booking> listOfBookingToShow = new ArrayList<Booking>();
		for (Booking booking : listOfBookings) {

			if (booking.getUser().getUserId() == user.getUserId()) {
				listOfBookingToShow.add(booking);
			}

		}

		model.addAttribute("listOfBookingToShow", listOfBookingToShow);
		return "bookinghistory";

	}

	@RequestMapping("/search")
	public String searchRoom(Model model) {
		Room room = new Room();
		model.addAttribute("room", room);

		Hotel hotel = new Hotel();
		model.addAttribute("hotel", hotel);
		return "searchroom";
	}

	@RequestMapping(value = "/showHotels", method = RequestMethod.POST)
	public String showHotels(Model model, @ModelAttribute("room") Room room, @ModelAttribute("hotel") Hotel hotel) {
		List<Hotel> listOfHotels=hotelService.getHotelList();
		
		List<Hotel> listOfHotelsToShow=new ArrayList<Hotel>();
		
		for (Hotel hotel1 : listOfHotels) {
			
			for (Room roominhotel : hotel1.getRoom()) {
				if(roominhotel.getRoomType().equalsIgnoreCase(room.getRoomType()))
				{
					listOfHotelsToShow.add(hotel);
				}
				
			}
			
		}
		model.addAttribute("listOfHotelsToShow", listOfHotelsToShow);
		return "showHotels";

	}

}