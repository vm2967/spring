package com.example.demo.serviceinterface.service;

import com.example.demo.serviceinterface.RoomInterface;

public class RoomService implements RoomInterface{

}
