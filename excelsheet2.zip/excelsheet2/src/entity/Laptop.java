package entity;

public class Laptop {
	
	private long laptopId;
	private String brand;
	private double cost;
	public Laptop() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Laptop(long laptopId, String brand, double cost) {
		super();
		this.laptopId = laptopId;
		this.brand = brand;
		this.cost = cost;
	}
	public long getLaptopId() {
		return laptopId;
	}
	public void setLaptopId(long laptopId) {
		this.laptopId = laptopId;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	@Override
	public String toString() {
		return "Laptop [laptopId=" + laptopId + ", brand=" + brand + ", cost=" + cost + "]";
	}
	
	
	
	

}
