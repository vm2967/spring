package client;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import entity.Laptop;
import entity.User;

public class ReadAndWrite {
	
	public  void write() {
	
		Map<User, List<Laptop>> map=new HashMap<User, List<Laptop>>();
		List<Laptop> list=new ArrayList<>();
		list.add(new Laptop(1,"Dell",30000));
		list.add(new Laptop(2,"Hp",40000));
		list.add(new Laptop(3,"Asus",25000));
		list.add(new Laptop(4,"Lenovo",60000));
		list.add(new Laptop(5,"Acer",50000));
		
		map.put(new User(1221,"Vikas"), list);
		
		List<Laptop> list1=new ArrayList<>();
		list1.add(new Laptop(6,"apple",30000));
		list1.add(new Laptop(7,"dell",40000));
		list1.add(new Laptop(8,"asus",25000));
		list1.add(new Laptop(9,"Lenovo",60000));
		list1.add(new Laptop(10,"acer",50000));
		
		map.put(new User(1331,"Shubham"), list1);
		
		XSSFWorkbook workbook=new XSSFWorkbook();
		XSSFSheet sheet=workbook.createSheet("user laptop details");
		int rownum=0;
		for(Entry<User, List<Laptop>> entry:map.entrySet()) {
			Row row=sheet.createRow(rownum++);
			Cell cell0=row.createCell(0);
			cell0.setCellValue(entry.getKey().getUserId());
			Cell cell1=row.createCell(1);
			cell1.setCellValue(entry.getKey().getUserName());
			for(Laptop laptop :entry.getValue()) {
				Row row11=sheet.createRow(rownum++);
				Cell cell01=row11.createCell(0);
				cell01.setCellValue(laptop.getLaptopId());
				Cell cell02=row11.createCell(1);
				cell02.setCellValue(laptop.getBrand());
				Cell cell03=row11.createCell(2);
				cell03.setCellValue(laptop.getCost());
			}
		}
		
		FileOutputStream fos;
		try {
			fos=new FileOutputStream("D:/vikas123.xlsx");
			workbook.write(fos);
			fos.close();
			workbook.close();
			System.out.println("Successfully written");
			
		} catch (Exception e){
			System.out.println(e.getMessage());
		}
	
			
	}
	
	@SuppressWarnings("deprecation")
	public void read() {
		
		try {
			FileInputStream fis = new FileInputStream("D:/vikas123.xlsx");
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet("user laptop details");
			//iterating through each rows one by one
			Iterator<Row> rowiter = sheet.iterator();
			while (rowiter.hasNext()) {
				Row rownext = rowiter.next();
				Iterator<Cell> celliterator = rownext.iterator();
				while (celliterator.hasNext()) {
					Cell cell = celliterator.next();
					//check the cell type and format accordingly
					switch (cell.getCellType()) {
					case  Cell.CELL_TYPE_NUMERIC:
						System.out.println(cell.getNumericCellValue());
						break;
					case  Cell.CELL_TYPE_STRING:
					   System.out.println(cell.getStringCellValue());
						break;
					}
					System.out.println();
				}
			}
			workbook.close();
			fis.close();
			System.out.println("Successfully readen");
		} catch (IOException e) {

			System.out.println(e.getMessage());
		}
		
		
	}

	
}
	


	


