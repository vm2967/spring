package client;

import java.util.Scanner;

public class MainRunner {
	
public static void main(String[] args) {
		
	System.out.println("Enter 1 for write operation \n Enter 2 for read operation \n 3 to exit..");
	Scanner sc=new Scanner(System.in);
	boolean flag=true;
	
	ReadAndWrite rw=new ReadAndWrite();
	
	while(flag)
	{
		int choice=sc.nextInt();
		
	  if(choice==1)
		rw.write();
	else if(choice==2)
		rw.read();
	else 
	    flag=false;
	}
	}

}
