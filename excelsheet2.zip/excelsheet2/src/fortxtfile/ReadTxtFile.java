package fortxtfile;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReadTxtFile {
	public static void main(String[] args) {
		
		String line=null;
		
		FileReader fr;
		
		try {
			fr=new FileReader("name.txt");
			//FileWriter fw=new FileWriter("names.txt");
			BufferedReader bufferedReader=new BufferedReader(fr);
			while((line=bufferedReader.readLine())!=null) {
				System.out.println(line);
				//fw.write(line+"\n");
			}
			bufferedReader.close(); 
			//fw.close();
			fr.close();
			
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}

}
