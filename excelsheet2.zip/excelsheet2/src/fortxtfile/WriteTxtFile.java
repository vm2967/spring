package fortxtfile;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class WriteTxtFile {
	
	public static void main(String[] args) {
		
		List<String> list=new ArrayList<>();
		list.add("vikas");
		list.add("saurav");
		list.add("anand");
		list.add("siba");
		list.add("swapnil");
		
		FileWriter fw;
		try {
			fw=new FileWriter("name.txt");
			BufferedWriter bufferwriter=new BufferedWriter(fw);
			for (String string : list) {
				bufferwriter.write(string+"\n");
				
			}	
			bufferwriter.close();
			System.out.println("File writing succesfull");
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		
	}

}
