package client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import entity.Author;
import entity.BestSeller;
import entity.Book;
import entity.Library;
import service.MethodStatic;
import service.Service;

public class Client implements MethodStatic {

	public static void main(String[] args) {
		Map<Library, Map<Author, Set<Book>>> library1 = new HashMap<Library, Map<Author, Set<Book>>>();
		Map<Author, Set<Book>> author1 = new TreeMap<Author, Set<Book>>();
		Set<Book> book1 = new HashSet<Book>();
		book1.add(new Book(1, "Alchemist"));
		book1.add(new Book(2, "Tremis"));
		author1.put(new Author(1, "Paulo", 60), book1);

		Set<Book> book2 = new HashSet<Book>();
		book2.add(new Book(1, "RochakKahani"));
		book2.add(new Book(2, "Rochak"));
		book2.add(new Book(3, "Kahani"));
		book2.add(new Book(4, "Zindagi"));
		author1.put(new Author(2, "MunshiPremchand", 50), book2);

		library1.put(new Library(1, "StarLibrary"), author1);

		Iterator<Map.Entry<Library, Map<Author, Set<Book>>>> itr = library1.entrySet().iterator();
		while (itr.hasNext()) {

			// Map.Entry<Library, Map<Author, Set<Book>>> entry = itr.next();
			// System.out.println(entry.getKey());
			System.out.println(itr.next().getKey());

			author1.forEach((key, value) -> {

				System.out.println(key.getAuthorId() + "***" + key.getAuthorName() + "***" + key.getAuthorAge());

				value.forEach(e -> System.out.println(e));

			});
		}

		Service ser = () -> {

			List<BestSeller> sellers = new ArrayList<BestSeller>();
			sellers = author1.entrySet().stream().filter(e -> e.getValue().size() > 2)
					.map(m -> new BestSeller(m.getKey().getAuthorId(), m.getKey().getAuthorName(), m.getValue().size(),
							m.getKey().getAuthorAge()))
					.collect(Collectors.toList());
			return sellers;

		};

		MethodStatic.collect(ser.add());

		int sum = ser.add().stream().filter(e -> e.getTotalBooksSold() > 3).mapToInt(m -> m.getSellerAge()).reduce(0,
				(a, b) -> (a + b));
		System.out.println("Sum is->" + sum);
	}

}
