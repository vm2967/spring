package entity;

public class BestSeller {
	private int sellerId;
	private String sellerName;
	private int totalBooksSold;
	private int sellerAge;
	public BestSeller() {
		super();
		
	}
	public BestSeller(int sellerId, String sellerName, int totalBooksSold, int sellerAge) {
		super();
		this.sellerId = sellerId;
		this.sellerName = sellerName;
		this.totalBooksSold = totalBooksSold;
		this.sellerAge = sellerAge;
	}
	public int getSellerId() {
		return sellerId;
	}
	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}
	public String getSellerName() {
		return sellerName;
	}
	public void setSellerName(String sellerName) {
		this.sellerName = sellerName;
	}
	public int getTotalBooksSold() {
		return totalBooksSold;
	}
	public void setTotalBooksSold(int totalBooksSold) {
		this.totalBooksSold = totalBooksSold;
	}
	public int getSellerAge() {
		return sellerAge;
	}
	public void setSellerAge(int sellerAge) {
		this.sellerAge = sellerAge;
	}
	@Override
	public String toString() {
		return "BestSeller [sellerId=" + sellerId + ", sellerName=" + sellerName + ", totalBooksSold=" + totalBooksSold
				+ ", sellerAge=" + sellerAge + "]";
	}
	

}
