package service;

import java.util.List;
import java.util.stream.Collectors;

import entity.BestSeller;

public interface MethodStatic {

	static void collect(List<BestSeller> seller) {

		List<BestSeller> sellers = seller.stream().filter(e -> e.getSellerAge() > 18)
				.filter(e1 -> e1.getTotalBooksSold() > 3).collect(Collectors.toList());

	
		sellers.forEach(e3->System.out.println(e3));
		
	}

}
