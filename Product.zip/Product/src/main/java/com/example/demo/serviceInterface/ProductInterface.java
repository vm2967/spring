package com.example.demo.serviceInterface;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Product;
@Service

public interface ProductInterface {

	List<Product> listAll();

	void save(Product product);

	Product get(long id);

	void delete(long id);


}
