package com.example.demo.serviceInterface.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Product;
import com.example.demo.repository.ProductRepository;
import com.example.demo.serviceInterface.ProductInterface;
@Service

public class ProductServiceImpli implements ProductInterface{
	@Autowired
	ProductRepository productRepo;

	@Override
	public List<Product> listAll() {
		return productRepo.findAll();
	}

	@Override
	public void save(Product product) {
		productRepo.save(product);
		
	}

	@Override
	public Product get(long id) {
		
		return productRepo.findById(id).get();
	}

	@Override
	public void delete(long id) {
		productRepo.deleteById(id);
		
	}
	
	

	
}
