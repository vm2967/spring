package com.example.demo.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.example.demo.entity.Food;
import com.example.demo.serviceInterface.FoodInterface;

@Controller
public class FoodController {
	@Autowired
	FoodInterface food;
	@RequestMapping("/")
	public String get() {
		return "index";
	}
	@RequestMapping("/add")
	public String insertData() {
		return "add";
	}
	@RequestMapping("/show")
	public String showData(Model model) {
		model.addAttribute("food",food.getAllFood());
		return "showdata";
		
	}
	@RequestMapping("/edit/{id}")
	public ModelAndView editData(@PathVariable int id) {
		ModelAndView model=new ModelAndView("update");
		model.addObject("food1",food.getFood(id));
		return model;
	}
	@RequestMapping(value="/save",method=RequestMethod.POST)
	public String foodRegistration(@ModelAttribute("food") Food pass) {
		food.addFood(pass);
		return "redirect:/";
	}
	@RequestMapping(value="/savedata",method=RequestMethod.POST)
	public String foodEdit(@ModelAttribute("food") Food pass) {
		food.addFood(pass);
		return "redirect:/show";
		
	}

}
