package com.example.demo.serviceInterface.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.entity.Food;
import com.example.demo.repository.FoodRepository;
import com.example.demo.serviceInterface.FoodInterface;
@Service

public class FoodService implements FoodInterface{
	@Autowired
	private FoodRepository food;

	@Override
	public List<Food> getAllFood() {
		
		return food.findAll() ;
	}

	@Override
	public Food getFood(int id) {
		
		return food.findById(id).orElse(null);
	}

	@Override
	public void addFood(Food pass) {
		food.save(pass);
		
	}

}
