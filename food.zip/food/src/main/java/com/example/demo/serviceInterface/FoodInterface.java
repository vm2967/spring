package com.example.demo.serviceInterface;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Food;

@Service
public interface FoodInterface {

	List<Food> getAllFood();

	Food getFood(int id);

	void addFood(Food pass);

	

}
