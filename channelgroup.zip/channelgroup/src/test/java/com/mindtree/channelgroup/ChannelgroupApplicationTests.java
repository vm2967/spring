package com.mindtree.channelgroup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChannelgroupApplicationTests {

	@Test
	void contextLoads() {
	}

}
