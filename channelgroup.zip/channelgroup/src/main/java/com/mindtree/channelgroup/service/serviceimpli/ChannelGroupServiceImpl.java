package com.mindtree.channelgroup.service.serviceimpli;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.channelgroup.dto.ChannelDto;
import com.mindtree.channelgroup.dto.ChannelGroupDto;
import com.mindtree.channelgroup.entity.Channel;
import com.mindtree.channelgroup.entity.ChannelGroup;
import com.mindtree.channelgroup.exception.NoSuchGroupException;
import com.mindtree.channelgroup.exception.ServiceException;
import com.mindtree.channelgroup.repository.ChannelGroupRepository;
import com.mindtree.channelgroup.service.ChannelGroupService;
@Service
public class ChannelGroupServiceImpl implements ChannelGroupService {
	@Autowired
	private ChannelGroupRepository channelGroupRepo;
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public ChannelGroupDto addChannelGroup(ChannelGroupDto channelGroupDto) {
		ChannelGroup channelGroup=modelMapper.map(channelGroupDto, ChannelGroup.class);
		channelGroupRepo.save(channelGroup);
		return channelGroupDto;
	}

	@Override
	public List<ChannelDto> displayChannels(int groupId) throws ServiceException {
	ChannelGroup channelGroup=channelGroupRepo.findById(groupId).orElseThrow(()->new NoSuchGroupException("No Such type of group Exists"));
	List<Channel> channels=	channelGroup.getChannel();
	List<ChannelDto> channelDto=new ArrayList<ChannelDto>();
	channels.forEach(e->channelDto.add(modelMapper.map(e, ChannelDto.class)));
		return channelDto;
	}

}
