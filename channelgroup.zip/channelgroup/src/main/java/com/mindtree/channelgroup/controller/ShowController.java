package com.mindtree.channelgroup.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.channelgroup.dto.ShowDto;
import com.mindtree.channelgroup.exception.ApplicationException;

import com.mindtree.channelgroup.service.ShowService;

@RestController
public class ShowController {
	@Autowired
	ShowService showService;
	
	@PostMapping(value="/addShow")
	public ResponseEntity<?> addShows(@RequestBody ShowDto showDto){
		ShowDto showDto1=showService.addShows(showDto);
		return new ResponseEntity<ShowDto>(showDto1, HttpStatus.ACCEPTED);
		
	}
	
	@PutMapping(value="/assignChannelToShow/{channelId}/{showId}")
	public ResponseEntity<?> assignChannelToShow(@PathVariable int channelId,@PathVariable int showId) throws ApplicationException{
		String st=showService.assignChannelToshow(channelId,showId);
		return new ResponseEntity<String>(st, HttpStatus.ACCEPTED);
		
		
	}
	

}
