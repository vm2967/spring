package com.mindtree.channelgroup.exception;

public class NoSuchShowException extends ServiceException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoSuchShowException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoSuchShowException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public NoSuchShowException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NoSuchShowException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NoSuchShowException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
