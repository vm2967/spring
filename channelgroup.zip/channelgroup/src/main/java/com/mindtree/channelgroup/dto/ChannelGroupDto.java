package com.mindtree.channelgroup.dto;



public class ChannelGroupDto {
	
	private int groupId;
	private String groupName;
	
	
	

	public ChannelGroupDto() {
		super();
		// TODO Auto-generated constructor stub
	}


	


	public ChannelGroupDto(int groupId, String groupName) {
		super();
		this.groupId = groupId;
		this.groupName = groupName;
	}





	public int getGroupId() {
		return groupId;
	}


	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}


	public String getGroupName() {
		return groupName;
	}


	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}


	

}
