package com.mindtree.channelgroup.service.serviceimpli;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.channelgroup.dto.ShowDto;
import com.mindtree.channelgroup.entity.Channel;
import com.mindtree.channelgroup.entity.Show;
import com.mindtree.channelgroup.exception.NoSuchChannelException;
import com.mindtree.channelgroup.exception.NoSuchShowException;
import com.mindtree.channelgroup.exception.ServiceException;
import com.mindtree.channelgroup.repository.ChannelRepository;
import com.mindtree.channelgroup.repository.ShowRepository;
import com.mindtree.channelgroup.service.ShowService;
@Service
public class ShowServiceImpl implements ShowService{
	
	@Autowired
	private ShowRepository showRepo;
	
	@Autowired
	private ChannelRepository channelRepo;
	
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public ShowDto addShows(ShowDto showDto) {
		Show show=modelMapper.map(showDto, Show.class);
		showRepo.save(show);
		return showDto;
	}

	@Override
	public String assignChannelToshow(int channelId, int showId) throws ServiceException {
		Channel channel=channelRepo.findById(channelId).orElseThrow(()->new NoSuchChannelException("No such Channel Exists"));
		Show show=showRepo.findById(showId).orElseThrow(()->new NoSuchShowException("No such Show Exist"));
		show.setChannel(channel);
		showRepo.save(show);
		return" assigned Succesfully";
	}
	

}
