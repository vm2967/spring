package com.mindtree.channelgroup.service;

import com.mindtree.channelgroup.dto.ShowDto;
import com.mindtree.channelgroup.exception.ServiceException;

public interface ShowService {

	ShowDto addShows(ShowDto showDto);

	String assignChannelToshow(int channelId, int showId) throws ServiceException;

}
