package com.mindtree.channelgroup.dto;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.mindtree.channelgroup.entity.ChannelGroup;


public class ChannelDto {
	
	private int channelId;
	private String channelName;
	private double channelPrice;
	
	
	@JsonIgnore
	private ChannelGroup channelGroup;
	
	
	


	public ChannelDto() {
		super();
		// TODO Auto-generated constructor stub
	}


	

	public ChannelDto(int channelId, String channelName, double channelPrice, ChannelGroup channelGroup) {
		super();
		this.channelId = channelId;
		this.channelName = channelName;
		this.channelPrice = channelPrice;
		this.channelGroup = channelGroup;
	}




	public int getChannelId() {
		return channelId;
	}


	public void setChannelId(int channelId) {
		this.channelId = channelId;
	}


	public String getChannelName() {
		return channelName;
	}


	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}


	public double getChannelPrice() {
		return channelPrice;
	}


	public void setChannelPrice(double channelPrice) {
		this.channelPrice = channelPrice;
	}


	public ChannelGroup getChannelGroup() {
		return channelGroup;
	}


	public void setChannelGroup(ChannelGroup channelGroup) {
		this.channelGroup = channelGroup;
	}


	
	

}
