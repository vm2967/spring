package com.mindtree.channelgroup.service;

import com.mindtree.channelgroup.dto.ChannelDto;
import com.mindtree.channelgroup.exception.ServiceException;

public interface ChannelService {

	ChannelDto addChannels(ChannelDto channelDto);

	String assignGroupToChannel(int groupId, int channelId) throws ServiceException;

}
