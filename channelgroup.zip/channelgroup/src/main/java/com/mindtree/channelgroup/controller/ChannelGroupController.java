package com.mindtree.channelgroup.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.channelgroup.dto.ChannelDto;
import com.mindtree.channelgroup.dto.ChannelGroupDto;
import com.mindtree.channelgroup.exception.ApplicationException;
import com.mindtree.channelgroup.service.ChannelGroupService;

@RestController
public class ChannelGroupController {
	@Autowired
	private ChannelGroupService channelGroupService;
	
	@PostMapping(value="/addChannelGroup")
	public ResponseEntity<?> addChannelGroup(@RequestBody ChannelGroupDto channelGroupDto){
		ChannelGroupDto channelGroupDto2=channelGroupService.addChannelGroup(channelGroupDto);
		return new ResponseEntity<ChannelGroupDto>(channelGroupDto2, HttpStatus.ACCEPTED);
		
		
	}
	
	@GetMapping(value="/displayChannels/{groupId}")
	public ResponseEntity<?> displayChannels(@PathVariable int groupId) throws ApplicationException{
		List<ChannelDto>channelDto=channelGroupService.displayChannels(groupId);
		
		return new ResponseEntity<List<ChannelDto>>(channelDto, HttpStatus.FOUND);
		
	}
	

}
