package com.mindtree.channelgroup.service;

import java.util.List;

import com.mindtree.channelgroup.dto.ChannelDto;
import com.mindtree.channelgroup.dto.ChannelGroupDto;
import com.mindtree.channelgroup.exception.ServiceException;

public interface ChannelGroupService {

	ChannelGroupDto addChannelGroup(ChannelGroupDto channelGroupDto);

	List<ChannelDto> displayChannels(int groupId) throws ServiceException;

}
