package com.mindtree.channelgroup.service.serviceimpli;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindtree.channelgroup.dto.ChannelDto;
import com.mindtree.channelgroup.entity.Channel;
import com.mindtree.channelgroup.entity.ChannelGroup;
import com.mindtree.channelgroup.exception.NoSuchChannelException;
import com.mindtree.channelgroup.exception.NoSuchGroupException;
import com.mindtree.channelgroup.exception.ServiceException;
import com.mindtree.channelgroup.repository.ChannelGroupRepository;
import com.mindtree.channelgroup.repository.ChannelRepository;
import com.mindtree.channelgroup.service.ChannelService;
@Service
public class ChannelServiceImpl implements ChannelService{

	@Autowired
	private ChannelRepository channelRepo;
	@Autowired
	private ChannelGroupRepository channelGRepo;
	@Autowired
	private ModelMapper modelMapper;
	@Override
	public ChannelDto addChannels(ChannelDto channelDto) {
		Channel channel=modelMapper.map(channelDto, Channel.class);
		channelRepo.save(channel);
		return channelDto;
	}
	@Override
	public String assignGroupToChannel(int groupId, int channelId) throws ServiceException {
		ChannelGroup channelGroup=channelGRepo.findById(groupId).orElseThrow(()->new NoSuchGroupException("No such Group Exception"));
		Channel channel=channelRepo.findById(channelId).orElseThrow(()->new NoSuchChannelException("No such channel Exception"));
		channel.setChannelGroup(channelGroup);
		channelRepo.save(channel);
		return "assigned Successfully";
	}

}
