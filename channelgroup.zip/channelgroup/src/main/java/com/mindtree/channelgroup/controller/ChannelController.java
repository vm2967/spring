package com.mindtree.channelgroup.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.channelgroup.dto.ChannelDto;
import com.mindtree.channelgroup.exception.ApplicationException;

import com.mindtree.channelgroup.service.ChannelService;

@RestController
public class ChannelController {
	@Autowired
	private ChannelService channelService;
	
	@PostMapping(value="/addChannel")
	public ResponseEntity<?> addChannel(@RequestBody ChannelDto channelDto){
		
		ChannelDto channelDto1=channelService.addChannels(channelDto);
		return new ResponseEntity<ChannelDto>(channelDto1, HttpStatus.ACCEPTED);
		
		
	}
	
	@PutMapping(value="/assignGroup/{groupId}/{channelId}")
	public ResponseEntity<?> assignGroupToChannel(@PathVariable int groupId,@PathVariable int channelId) throws ApplicationException{
		String str=channelService.assignGroupToChannel(groupId,channelId);
		return new ResponseEntity<String>(str, HttpStatus.FOUND);
		
	}

}
