package com.mindtree.channelgroup.dto;



import com.fasterxml.jackson.annotation.JsonIgnore;
import com.mindtree.channelgroup.entity.Channel;

public class ShowDto {
	private int showId;
	private String showName;
	
	@JsonIgnore
	private Channel channel;

	public ShowDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ShowDto(int showId, String showName, Channel channel) {
		super();
		this.showId = showId;
		this.showName = showName;
		this.channel = channel;
	}

	public int getShowId() {
		return showId;
	}

	public void setShowId(int showId) {
		this.showId = showId;
	}

	public String getShowName() {
		return showName;
	}

	public void setShowName(String showName) {
		this.showName = showName;
	}

	public Channel getChannel() {
		return channel;
	}

	public void setChannel(Channel channel) {
		this.channel = channel;
	}
	
	

}
