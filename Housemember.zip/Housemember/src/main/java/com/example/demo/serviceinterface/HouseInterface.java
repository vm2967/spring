package com.example.demo.serviceinterface;

import com.example.demo.dto.HouseDto;
import com.example.demo.entity.House;
import com.example.demo.exception.ServiceException;

public interface HouseInterface {

	String add(HouseDto housedto) throws ServiceException;

}
