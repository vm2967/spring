package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;


@Entity
public class Member implements Comparable<Member> {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int memberId;
	private String memberName;
	private String gender;
	private  int memberAge;
	
	@ManyToOne(fetch = FetchType.LAZY)
	private House house;

	public Member() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Member(int memberId, String memberName, String gender, int memberAge, House house) {
		super();
		this.memberId = memberId;
		this.memberName = memberName;
		this.gender = gender;
		this.memberAge = memberAge;
		this.house = house;
	}

	public int getMemberId() {
		return memberId;
	}

	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getMemberAge() {
		return memberAge;
	}

	public void setMemberAge(int memberAge) {
		this.memberAge = memberAge;
	}

	public House getHouse() {
		return house;
	}

	public void setHouse(House house) {
		this.house = house;
	}

	@Override
	public String toString() {
		return "Member [memberId=" + memberId + ", memberName=" + memberName + ", gender=" + gender + ", memberAge="
				+ memberAge + ", house=" + house + "]";
	}

	@Override
	public int compareTo(Member arg0) {
		
		return this.getMemberAge()-arg0.getMemberAge();
	}
	
	
	

}
