package com.example.demo.entity;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class House {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int houseId;
	@Column(unique = true)
	private String houseName;
	private String houseAddress;
	
	@OneToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL,mappedBy = "house")
	private List<Member> member;

	public House() {
		super();
		
	}

	public House(int houseId, String houseName, String houseAddress, List<Member> member) {
		super();
		this.houseId = houseId;
		this.houseName = houseName;
		this.houseAddress = houseAddress;
		this.member = member;
	}

	public int getHouseId() {
		return houseId;
	}

	public void setHouseId(int houseId) {
		this.houseId = houseId;
	}

	public String getHouseName() {
		return houseName;
	}

	public void setHouseName(String houseName) {
		this.houseName = houseName;
	}

	public String getHouseAddress() {
		return houseAddress;
	}

	public void setHouseAddress(String houseAddress) {
		this.houseAddress = houseAddress;
	}

	public List<Member> getMember() {
		return member;
	}

	public void setMember(List<Member> member) {
		this.member = member;
	}

	@Override
	public String toString() {
		return "House [houseId=" + houseId + ", houseName=" + houseName + ", houseAddress=" + houseAddress + ", member="
				+ member + "]";
	}
	
	

	
}
