package com.example.demo.dto;

import java.util.List;

public class HouseDto {
	private String houseName;
	private String houseAddress;
	private List<MemberDto> member;
	public HouseDto() {
		super();
		
	}
	public HouseDto(String houseName, String houseAddress, List<MemberDto> member) {
		super();
		this.houseName = houseName;
		this.houseAddress = houseAddress;
		this.member = member;
	}

	public String getHouseName() {
		return houseName;
	}
	public void setHouseName(String houseName) {
		this.houseName = houseName;
	}
	public String getHouseAddress() {
		return houseAddress;
	}
	public void setHouseAddress(String houseAddress) {
		this.houseAddress = houseAddress;
	}

	public List<MemberDto> getMember() {
		return member;
	}

	public void setMember(List<MemberDto> member) {
		this.member = member;
	}
	
	
}
