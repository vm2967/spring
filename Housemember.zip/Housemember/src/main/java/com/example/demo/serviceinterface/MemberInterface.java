package com.example.demo.serviceinterface;

import java.util.List;

import com.example.demo.dto.MemberDto;


public interface MemberInterface {

	String addMember(String houseName, MemberDto memberDto);

	List<MemberDto> findHous(int memberId);

}
