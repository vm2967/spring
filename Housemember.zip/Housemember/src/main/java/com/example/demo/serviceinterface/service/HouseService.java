package com.example.demo.serviceinterface.service;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.HouseDto;
import com.example.demo.entity.House;
import com.example.demo.exception.HotelExistsException;
import com.example.demo.exception.ServiceException;
import com.example.demo.repository.HouseRepository;
import com.example.demo.serviceinterface.HouseInterface;

@Service
public class HouseService implements HouseInterface {
	
	@Autowired
	HouseRepository houseRepo;
	
	@Autowired
	ModelMapper modelMapper;
	
	@Override
	public String add(HouseDto housedto) throws ServiceException {
		
		try {
			House house=modelMapper.map(housedto, House.class);
			
			houseRepo.save(house);
		}
		catch(Exception e) {
			throw new HotelExistsException("This House is Already Exist");
			
		}
		return "house added successfully";
	}

}
