package com.example.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.dto.MemberDto;
import com.example.demo.serviceinterface.MemberInterface;

@RestController
public class MemberController {
	@Autowired
	MemberInterface memberService;
	
	@PostMapping(value="/addMember/{houseName}")
	public ResponseEntity<?>addMember(@PathVariable String houseName ,@RequestBody MemberDto memberDto ){
		String m=memberService.addMember(houseName,memberDto);
		return new ResponseEntity<String>(m, HttpStatus.ACCEPTED);
		
	}
	
	@GetMapping(value="/findHouse/{memberId}")
	public ResponseEntity<?> findHouse(@PathVariable int memberId){
		
		List<MemberDto> list=memberService.findHous(memberId);
		return new ResponseEntity<List<MemberDto>>(list, HttpStatus.ACCEPTED);
	}
	

}
