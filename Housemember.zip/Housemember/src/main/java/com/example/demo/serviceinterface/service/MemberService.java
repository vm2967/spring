package com.example.demo.serviceinterface.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.dto.MemberDto;
import com.example.demo.entity.House;
import com.example.demo.entity.Member;
import com.example.demo.repository.HouseRepository;
import com.example.demo.repository.MemberRepository;

import com.example.demo.serviceinterface.MemberInterface;

@Service
public class MemberService implements MemberInterface {
	@Autowired
	MemberRepository memberRepo;
	@Autowired
	HouseRepository houseRepo;

	@Autowired
	ModelMapper modelMapper;

	@Override
	public String addMember(String houseName, MemberDto memberdto) {
		House house = houseRepo.findByhouseName(houseName);
		Member member=modelMapper.map(memberdto, Member.class);
		member.setHouse(house);
		memberRepo.save(member);
		return "member added succesfully";
	}

	@Override
	public List<MemberDto> findHous(int memberId) {
		Member member = memberRepo.findById(memberId).get();
		House house = member.getHouse();
		List<Member> list = house.getMember();
		Collections.sort(list);
		List<MemberDto> listDto = new ArrayList<MemberDto>();
		for (Member member1 : list) {

			listDto.add(modelMapper.map(member1, MemberDto.class));

		}
		return listDto;
	}

}
