package com.example.demo.dto;

import com.example.demo.entity.House;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class MemberDto {
	
	private String memberName;
	private String gender;
	private  int memberAge;
	@JsonIgnore
	private House house;
	
	public MemberDto() {
		super();
		
	}
	public MemberDto(String memberName, String gender, int memberAge, House house) {
		super();
		this.memberName = memberName;
		this.gender = gender;
		this.memberAge = memberAge;
		this.house = house;
	}

	
	public House getHouse() {
		return house;
	}

	public void setHouse(House house) {
		this.house = house;
	}

	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getMemberAge() {
		return memberAge;
	}
	public void setMemberAge(int memberAge) {
		this.memberAge = memberAge;
	}
	

}
