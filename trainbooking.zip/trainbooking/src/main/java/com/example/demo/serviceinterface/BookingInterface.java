package com.example.demo.serviceinterface;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Booking;
import com.example.demo.entity.User;

/**
 * @author M1057754
 *
 */
@Service

public interface BookingInterface {

	/**
	 * @param user
	 * @param iD
	 * @param bookings
	 */
	void saveBookingsOfUser(User user, Integer iD, Booking bookings);

	/**
	 * @param user
	 * @return list
	 */
	List<Booking> detailOfUser(User user);

}
