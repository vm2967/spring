package com.example.demo.serviceinterface;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Booking;
import com.example.demo.entity.Trains;

/**
 * @author M1057754
 *
 */
@Service

public interface DaysInterface {

	/**
	 * @param bookings
	 * @return 
	 */
	Map<String, List<Trains>> getTrainAvailabiltyList(Booking bookings);

}
