package com.example.demo.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Trains {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int trainId;
	private String trainName;
	 private String trainSource;
	private String trainDestination;
	
	@OneToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL,mappedBy = "trains")
	private List<Booking> bookings;
	
	@ManyToMany(fetch = FetchType.LAZY)
	private List<Days> days;

	public Trains() {
		super();
		
	}

	public Trains(int trainId, String trainName, String trainSource, String trainDestination, List<Booking> bookings,
			List<Days> days) {
		super();
		this.trainId = trainId;
		this.trainName = trainName;
		this.trainSource = trainSource;
		this.trainDestination = trainDestination;
		this.bookings = bookings;
		this.days = days;
	}

	public int getTrainId() {
		return trainId;
	}

	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}

	public String getTrainName() {
		return trainName;
	}

	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}

	public String getTrainSource() {
		return trainSource;
	}

	public void setTrainSource(String trainSource) {
		this.trainSource = trainSource;
	}

	public String getTrainDestination() {
		return trainDestination;
	}

	public void setTrainDestination(String trainDestination) {
		this.trainDestination = trainDestination;
	}

	public List<Booking> getBookings() {
		return bookings;
	}

	public void setBookings(List<Booking> bookings) {
		this.bookings = bookings;
	}

	public List<Days> getDays() {
		return days;
	}

	public void setDays(List<Days> days) {
		this.days = days;
	}

	
	
}
