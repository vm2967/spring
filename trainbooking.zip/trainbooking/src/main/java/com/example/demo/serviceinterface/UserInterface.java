package com.example.demo.serviceinterface;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.User;

@Service

public interface UserInterface {

	List<User> getUserList();

	List<User> ListOfUser();

}
