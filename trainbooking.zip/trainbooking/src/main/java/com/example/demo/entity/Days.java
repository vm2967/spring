package com.example.demo.entity;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Days {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int dayId;
	private String days;
	@ManyToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL,mappedBy="days")
	private List<Trains> trains;
	public Days() {
		super();
		
	}
	public Days(int dayId, String days, List<Trains> trains) {
		super();
		this.dayId = dayId;
		this.days = days;
		this.trains = trains;
	}
	public int getDayId() {
		return dayId;
	}
	public void setDayId(int dayId) {
		this.dayId = dayId;
	}
	public String getDays() {
		return days;
	}
	public void setDays(String days) {
		this.days = days;
	}
	public List<Trains> getTrains() {
		return trains;
	}
	public void setTrains(List<Trains> trains) {
		this.trains = trains;
	}
	
}
