package com.example.demo.serviceinterface;

import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Trains;

/**
 * @author M1057754
 *
 */
@Service
public interface TrainInterface {

	/**
	 * @return
	 */
	Map<String, List<Trains>> getTrains();

	
}
