package com.example.demo.controller;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.entity.Booking;
import com.example.demo.entity.Trains;
import com.example.demo.entity.User;
import com.example.demo.serviceinterface.BookingInterface;
import com.example.demo.serviceinterface.DaysInterface;
import com.example.demo.serviceinterface.TrainInterface;
import com.example.demo.serviceinterface.UserInterface;

@Controller

public class TrainBookingController {

	int id = 0;
	Booking b;

	@Autowired
	TrainInterface trainService;

	@Autowired
	UserInterface userService;

	@Autowired
	DaysInterface daysService;

	@Autowired
	BookingInterface bookingService;

	@RequestMapping("/")
	public String homePage() {

		return "homepage";

	}

	@RequestMapping(value = "/booking", method = RequestMethod.GET)
	public String bookTicket(Model model) {

		Booking bookings = new Booking();
		model.addAttribute("bookings", bookings);
		return "bookingSearch";

	}

	@RequestMapping(value = "/availability")
	public String availability(Model model, @ModelAttribute("bookings") Booking bookings) {
		
		b = bookings;
		Map<String, List<Trains>> getTrainAvailabiltyList = daysService.getTrainAvailabiltyList(bookings);

		Map<String, List<Trains>> treeMap = new TreeMap<String, List<Trains>>(getTrainAvailabiltyList);

		model.addAttribute("treeMap", treeMap);

		return "availability";

	}

	@RequestMapping(value = "/bookUser/{trainId}")
	public String forBookingUserTicket(@PathVariable int trainId, Model model) {
		id = trainId;
		User user = new User();
		List<User> userList = userService.getUserList();
		model.addAttribute("userList", userList);
		model.addAttribute("user", user);

		return "bookTickets";
	}

	@RequestMapping(value = "/saveBooking", method = RequestMethod.POST)
	public String saveaddBooking(@ModelAttribute("user") User user, Integer ID, Booking bookings) {
		ID = id;
		bookings = b;
		bookingService.saveBookingsOfUser(user, ID, bookings);
		return "redirect:/";

	}
	
	@RequestMapping(value="/trainDetails")
	public String getTrainDetails(Model model) {
		Map<String, List<Trains>> getTrainList=trainService.getTrains();
//		getTrainList.entrySet().stream().forEach(e->{
//			System.out.println(e.getKey()+" : "+e.getValue());
//			
//		});
		
		model.addAttribute("getTrainList", getTrainList);
		return "checkTrains";
	}
	
	@RequestMapping(value="/travelHistory")
	public String HistoryOfTravel(Model model) {
		
		User user=new User();
		List<User> userList= userService.ListOfUser();
		model.addAttribute("userList", userList);
		model.addAttribute("user", user);
		
		return "history";
		
	}
	
	@RequestMapping(value="/showHistory")
	public String showHistory(@ModelAttribute("user") User user,Model model) {
		
		List<Booking> bookingHistory=bookingService.detailOfUser(user);
		model.addAttribute("bookingHistory", bookingHistory);
		
		return "history";
		
	}
}
