package com.example.demo.serviceinterface.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Trains;
import com.example.demo.repository.TrainRepository;
import com.example.demo.serviceinterface.TrainInterface;

@Service

public class TrainService implements TrainInterface{
	@Autowired
	TrainRepository trainRepo;

	@Override
	public Map<String, List<Trains>> getTrains() {
		Map<String, List<Trains>> getTrainList=new HashMap<String, List<Trains>>();
		for (Trains train : trainRepo.findAll()) {
			String str=train.getTrainSource() + "->" +train.getTrainDestination();
			if(getTrainList.containsKey(str)) {
				List<Trains> listtrain=getTrainList.get(str);
				listtrain.add(train);
				getTrainList.put(str, listtrain);
			}
			else {
				List<Trains>listtrain=new ArrayList<Trains>();
				listtrain.add(train);
				getTrainList.put(str, listtrain);
			}
				
		}
		
		return getTrainList;
	}

	
	

}
