package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Booking {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int bookingId;
	private String journeySource;
	private String journeyDestinaton;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	private User user;
	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	private Trains trains;


	public Booking() {
		super();
		
	}


	public Booking(int bookingId, String journeySource, String journeyDestinaton, User user, Trains trains) {
		super();
		this.bookingId = bookingId;
		this.journeySource = journeySource;
		this.journeyDestinaton = journeyDestinaton;
		this.user = user;
		this.trains = trains;
	}


	public int getBookingId() {
		return bookingId;
	}


	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}


	public String getJourneySource() {
		return journeySource;
	}


	public void setJourneySource(String journeySource) {
		this.journeySource = journeySource;
	}


	public String getJourneyDestinaton() {
		return journeyDestinaton;
	}


	public void setJourneyDestinaton(String journeyDestinaton) {
		this.journeyDestinaton = journeyDestinaton;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public Trains getTrains() {
		return trains;
	}


	public void setTrains(Trains trains) {
		this.trains = trains;
	}
	
	
	
	

	
	
}
