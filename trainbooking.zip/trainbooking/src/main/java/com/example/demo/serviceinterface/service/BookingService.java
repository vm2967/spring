package com.example.demo.serviceinterface.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Booking;
import com.example.demo.entity.Trains;
import com.example.demo.entity.User;
import com.example.demo.repository.BookingRepository;
import com.example.demo.repository.TrainRepository;
import com.example.demo.serviceinterface.BookingInterface;

@Service

public class BookingService implements BookingInterface{
	@Autowired
	BookingRepository bookingRepo;
	@Autowired
	TrainRepository trainRepo;

	@Override
	public void saveBookingsOfUser(User user, Integer iD, Booking bookings) {
		
		Trains trains=trainRepo.findById(iD).get();
		Booking book=bookingRepo.findById(bookings.getBookingId()).orElse(bookings);
		book.setUser(user);
		book.setTrains(trains);
		bookingRepo.save(book);
		
	}

	@Override
	public List<Booking> detailOfUser(User user) {
		List<Booking> bookings=user.getBookings();
		
		return bookings;
	}

}
