package com.example.demo.serviceinterface.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Booking;
import com.example.demo.entity.Days;
import com.example.demo.entity.Trains;
import com.example.demo.repository.TrainRepository;
import com.example.demo.serviceinterface.DaysInterface;

@Service

public class DaysService implements DaysInterface {

	@Autowired
	private TrainRepository trainRepo;

	@Override
	public Map<String, List<Trains>> getTrainAvailabiltyList(Booking bookings) {

		Map<String, List<Trains>> getTrains = new HashMap<String, List<Trains>>();

		List<Trains> trains = trainRepo.findAll().stream()
				.filter(tr -> tr.getTrainSource().equals(bookings.getJourneySource())
						&& tr.getTrainDestination().equals(bookings.getJourneyDestinaton()))
				.collect(Collectors.toList());
		
		
		for (Trains trains2 : trains) {
			
			for (Days day : trains2.getDays()) {
				if(getTrains.containsKey(day.getDays())) {
					List<Trains> listTrains=getTrains.get(day.getDays());
					
					listTrains.add(trains2);
					
					getTrains.put(day.getDays(), listTrains);
				}
				else {
					List<Trains> listTrains=new ArrayList<Trains>();
					listTrains.add(trains2);
					getTrains.put(day.getDays(), listTrains);
					
				}
				
			}
			
		}

		return getTrains;
	}

}
