$(function(){
	$.validator.addMethod('pattern', function(value, element) {
		return this.optional(element) || /[A-Za-z]+[0-9]/i.test(value);
	}, 'enter name should be alphanumeric')

	
	
	$("#register-form").validate({
		
		rules: {
			
			blockName: {
				
				required : true,
				pattern : true,
				minlength : 7

				
			}
		},
		message: {
			blockName: {
				required: "You must enter a Block name",
				minlength: "Username improper length",
				pattern: "Login format not valid"
			}
		}
		
		
	});
	
	
});
