package com.example.demo.serviceinterface.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Blocks;
import com.example.demo.repository.BlockRepository;
import com.example.demo.serviceinterface.BlockInterface;
@Service
public class BlockService implements BlockInterface {

	@Autowired
	BlockRepository blockRepo;
	
	@Override
	public void addKalingaBlock(Blocks block) {
		
		blockRepo.save(block);
		
	}

	@Override
	public List<Blocks> getAllBlocks() {
		
		return blockRepo.findAll();
	}

	

}
