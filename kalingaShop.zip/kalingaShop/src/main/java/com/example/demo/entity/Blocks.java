package com.example.demo.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity

public class Blocks {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int blockId;
	private String blockName;
	
	@OneToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL,mappedBy = "block")
	private List<Shops> shops;

	public Blocks() {
		super();
		
	}

	public Blocks(int blockId, String blockName, List<Shops> shops) {
		super();
		this.blockId = blockId;
		this.blockName = blockName;
		this.shops = shops;
	}

	public int getBlockId() {
		return blockId;
	}

	public void setBlockId(int blockId) {
		this.blockId = blockId;
	}

	public String getBlockName() {
		return blockName;
	}

	public void setBlockName(String blockName) {
		this.blockName = blockName;
	}

	public List<Shops> getShops() {
		return shops;
	}

	public void setShops(List<Shops> shops) {
		this.shops = shops;
	}
	
	
	

	
}
