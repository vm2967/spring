package com.example.demo.serviceinterface.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Dishes;
import com.example.demo.repository.DishesRepository;
import com.example.demo.serviceinterface.DishesInterface;

@Service
public class DishesService implements DishesInterface {

	@Autowired
	DishesRepository dishRepo;

	@Override
	public void addDish(Dishes dishes) {
		
		
		if (dishes.getShop().getRating() > 4.5) {

			dishes.setDishPrice(dishes.getDishPrice() - (dishes.getDishPrice() * 10 / 100));

		} else if (dishes.getShop().getRating() > 3.5) {
			dishes.setDishPrice(dishes.getDishPrice() - (dishes.getDishPrice() * 5 / 100));

		} else if (dishes.getShop().getRating() > 2.5) {
			dishes.setDishPrice(dishes.getDishPrice() - (dishes.getDishPrice() * 2 / 100));

		}

		dishRepo.save(dishes);

	}

	@Override
	public List<Dishes> showDishes(Long id) {

		List<Dishes> dishes = dishRepo.findAll();
		List<Dishes> dishesToShow = dishes.stream().filter(e -> e.getShop().getShopId() == id)
				.collect(Collectors.toList());

		return dishesToShow;
	}

}
