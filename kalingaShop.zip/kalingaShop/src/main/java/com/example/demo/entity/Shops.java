package com.example.demo.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity

public class Shops {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int shopId;
	private String shopName;
	private String shopType;
	private  float rating;
	
	@OneToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL,mappedBy = "shop")
	private List<Dishes> shopdishes;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JsonIgnore
	private Blocks block;

	public Shops() {
		super();
		
	}

	public Shops(int shopId, String shopName, String shopType,float rating, List<Dishes> shopdishes, Blocks block) {
		super();
		this.shopId = shopId;
		this.shopName = shopName;
		this.shopType = shopType;
		this.rating = rating;
		this.shopdishes = shopdishes;
		this.block = block;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getShopType() {
		return shopType;
	}

	public void setShopType(String shopType) {
		this.shopType = shopType;
	}

	public List<Dishes> getShopdishes() {
		return shopdishes;
	}

	public void setShopdishes(List<Dishes> shopdishes) {
		this.shopdishes = shopdishes;
	}

	public Blocks getBlock() {
		return block;
	}

	public void setBlock(Blocks block) {
		this.block = block;
	}

	@Override
	public String toString() {
		return "Shops [shopId=" + shopId + ", shopName=" + shopName + ", shopType=" + shopType + ", rating=" + rating
				+ ", shopdishes=" + shopdishes + ", block=" + block + "]";
	}
	
	
	

	

}
