package com.example.demo.serviceinterface;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Dishes;

@Service

public interface DishesInterface {

	void addDish(Dishes dishes);

	List<Dishes> showDishes(Long id);

}
