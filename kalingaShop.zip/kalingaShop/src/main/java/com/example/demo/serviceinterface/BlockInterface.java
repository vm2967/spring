package com.example.demo.serviceinterface;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Blocks;

@Service
public interface BlockInterface {

	void addKalingaBlock(Blocks block);

	List<Blocks> getAllBlocks();

	

}
