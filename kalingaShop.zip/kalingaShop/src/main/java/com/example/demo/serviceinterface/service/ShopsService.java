package com.example.demo.serviceinterface.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Blocks;
import com.example.demo.entity.Shops;
import com.example.demo.repository.BlockRepository;
import com.example.demo.repository.ShopsRepository;
import com.example.demo.serviceinterface.ShopsInterface;

@Service
public class ShopsService implements ShopsInterface {
	@Autowired
	ShopsRepository shopRepo;

	@Autowired
	BlockRepository blockRepo;

	@Override
	public void addShop(Shops shops) {

		shopRepo.save(shops);

	}

	@Override
	public List<Shops> getAllShops() {

		return shopRepo.findAll();
	}

	@Override
	public List<Shops> showShops(Shops shops) {

		List<Shops> allShops = shopRepo.findAll();

		List<Shops> shopsToShop = allShops.stream().filter(e -> e.getShopType().equalsIgnoreCase(shops.getShopType()))
				.collect(Collectors.toList());

		return shopsToShop;
	}

	@Override
	public List<Shops> getAllShopsByBlock(Blocks blocks) {
		List<Shops> listOfShop = shopRepo.findAll();
		List<Shops> listOfShopToShow = listOfShop.stream().filter(e -> e.getBlock().getBlockName() == blocks.getBlockName())
				.collect(Collectors.toList());
		return listOfShopToShow;
	}

}
