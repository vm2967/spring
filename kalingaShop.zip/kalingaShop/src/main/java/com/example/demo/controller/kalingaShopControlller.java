package com.example.demo.controller;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.entity.Blocks;
import com.example.demo.entity.Dishes;
import com.example.demo.entity.Shops;
import com.example.demo.serviceinterface.BlockInterface;
import com.example.demo.serviceinterface.DishesInterface;
import com.example.demo.serviceinterface.ShopsInterface;


@Controller

public class kalingaShopControlller {

	@Autowired
	BlockInterface blockService;

	@Autowired
	ShopsInterface shopsService;

	@Autowired
	DishesInterface dishService;

	@RequestMapping(value = "/")
	public String homePage() {
		return "homePage";

	}

	@RequestMapping(value = "/addBlock")
	public String addBlock(Model model) {

		Blocks blocks = new Blocks();
		model.addAttribute("blocks", blocks);

		return "addBlock";

	}

	@RequestMapping(value = "/saveblock", method = RequestMethod.POST)
	public String saveBlock(@ModelAttribute("block") Blocks block) {

		blockService.addKalingaBlock(block);
		return "redirect:/";

	}

	@RequestMapping(value = "/addShop")
	public String addShop(Model model) {
		Shops shops = new Shops();
		model.addAttribute("shops", shops);

		List<Blocks> blockListForDropDown = blockService.getAllBlocks();
		model.addAttribute("blockListForDropDown", blockListForDropDown);

		return "addShop";

	}

	@RequestMapping(value = "/saveshop", method = RequestMethod.POST)
	public String saveShop(@ModelAttribute("shops") Shops shops) {

		shopsService.addShop(shops);
		return "redirect:/";

	}

	@RequestMapping(value = "/addDish")
	public String addDish(Model model) {
		Dishes dishes = new Dishes();
		model.addAttribute("dishes", dishes);

		List<Shops> shopListForDropDown = shopsService.getAllShops();
		model.addAttribute("shopListForDropDown", shopListForDropDown);
		return "addDish";

	}

	@RequestMapping(value = "/savedish")
	public String saveDish(@ModelAttribute("dishes") Dishes dishes) {

		dishService.addDish(dishes);
		return "redirect:/";

	}

	@RequestMapping(value = "/showShops")
	public String showShops(Model model) {
		Shops shops = new Shops();
		model.addAttribute("shops", shops);
		return "showShops";

	}

	@RequestMapping(value = "/showShopss", method = RequestMethod.POST)
	public String showShopss(@ModelAttribute("shops") Shops shops, Model model) {
		List<Shops> shopsToShow = shopsService.showShops(shops);
		model.addAttribute("shopsToShow", shopsToShow);
		return "showShops2";

	}

	@RequestMapping("selectshop")
	public ModelAndView showDishes(@RequestParam Long id) {

		ModelAndView mav = new ModelAndView("showDishes");
		List<Dishes> dishesToShow = dishService.showDishes(id);
		mav.addObject("dishesToShow", dishesToShow);

		List<Dishes> descendingDishesToShow = dishesToShow.stream()
				.sorted(Comparator.comparingDouble(Dishes::getDishPrice).reversed()).collect(Collectors.toList());
		mav.addObject("descendingDishesToShow", descendingDishesToShow);
		List<Dishes> ascendingDishesToShow = dishesToShow.stream()
				.sorted(Comparator.comparingDouble(Dishes::getDishPrice)).collect(Collectors.toList());

		mav.addObject("ascendingDishesToShow", ascendingDishesToShow);
		
		return mav;

	}

	@RequestMapping(value = "/showShopsWithDishes")
	public String showShopsWithDishes(Model model) {
		List<Blocks> blockListForDropDown = blockService.getAllBlocks();
		model.addAttribute("blockListForDropDown", blockListForDropDown);
		Blocks blocks = new Blocks();
		model.addAttribute("blocks", blocks);
		return "showShopsWithDishes";

	}

	@RequestMapping(value = "/showShopsWithDishesss", method = RequestMethod.GET)
	public String showShopsWithDishes(Model model, @ModelAttribute("blocks") Blocks blocks) {

		List<Shops> shopListToShow = shopsService.getAllShopsByBlock(blocks);

		shopListToShow.forEach(e -> {
			System.out.println(e.getBlock().getBlockId() + " " + e.getBlock().getBlockName() + " " + e.getShopName());
		});

		model.addAttribute("shopListToShow", shopListToShow);

		return "showShopswithDishes2";

	}

}
