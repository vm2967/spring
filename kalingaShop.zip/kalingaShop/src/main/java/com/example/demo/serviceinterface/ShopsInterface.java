package com.example.demo.serviceinterface;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Blocks;
import com.example.demo.entity.Shops;

@Service

public interface ShopsInterface {

	void addShop(Shops shops);

	List<Shops> getAllShops();

	List<Shops> showShops(Shops shops);

	List<Shops> getAllShopsByBlock(Blocks blocks);

}
