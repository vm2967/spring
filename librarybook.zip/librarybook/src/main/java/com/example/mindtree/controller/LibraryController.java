package com.example.mindtree.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.mindtree.entity.Book;
import com.example.mindtree.entity.Library;
import com.example.mindtree.service.BookService;
import com.example.mindtree.service.LibraryService;

@Controller
public class LibraryController {

	@Autowired
	LibraryService libraryService;
	@Autowired
	BookService bookService;
	
	static int id=0;
	
	
	@RequestMapping("/")
	public String Library(Model model) {
		List<Library> library=libraryService.listLibrary();
		model.addAttribute("library", library);
		return "homePage";
		
	}
	
	@RequestMapping("/addlibrary")
	public String addLibrary(Model model) {
		Library library=new Library();
		model.addAttribute("library", library);
		return "addLibrary";
		
	}
	
	@RequestMapping(value="/savelibrary",method = RequestMethod.POST)
	public String saveLibrary(@ModelAttribute ("library") Library library) {
		libraryService.addLibrary(library);
		return "redirect:/";
		
	}
	
	@RequestMapping("/delete")
	public String deleteListLibrary(Model model) {
		List<Library> libraryListForDropDown=libraryService.listLibrary();
		model.addAttribute("libraryListForDropDown", libraryListForDropDown);
		return "deletePage";
		
	}
	
	@RequestMapping("/deletelibrary")
	public String deleteLibrary(@RequestParam("lib") int libraryId) {
		libraryService.deleteLibrary(libraryId);
		return "redirect:/";
	}
	
	@RequestMapping("/editlibrary/{libraryId}")
	public String editLibrary(@PathVariable int libraryId, Model model) {
		Library library=libraryService.updateLibraryById(libraryId);
		model.addAttribute("library", library);
		return "editLibrary";
		
	}
	
	@RequestMapping(value="/saveEdited",method = RequestMethod.POST)
	public String saveUpdatedLibrary(@ModelAttribute ("library") Library library) {
		libraryService.addLibrary(library);
		return "redirect:/";
		
	}
	
	@RequestMapping("/details/{libraryId}")
	public String detailsOfLib(@PathVariable int libraryId,Model model) {
		List<Book> book=bookService.getListOfBooks(libraryId);
		model.addAttribute("book", book);
		id=libraryId;
		return "detailsPage";
		
	}
	
	@RequestMapping("/addbook")
	public String addBook(Model model) {
		Book book =new Book();
		model.addAttribute("book",book);
		return "addBook";
		
	}
	@RequestMapping(value="/savebook",method = RequestMethod.POST)
	public String saveBook(@ModelAttribute ("book") Book book) {
		bookService.addBook(book,id);
		return "redirect:/";
		
	}
	
	@RequestMapping("/editbook/{bookId}")
	public String updateBook(@PathVariable int bookId,Model model) {
		Book book=bookService.updatebook(bookId);
		model.addAttribute("book", book);
		return "editBook";
		
	}
	
	@RequestMapping(value="/saveEditedBook",method = RequestMethod.POST)
	public String saveUpdatedBook(@ModelAttribute("book") Book book) {
		bookService.saveUpdated(book,id);
		return "redirect:/";
		
	}
	
	@RequestMapping("/deletebook/{bookId}")
	public String deleteBook(@PathVariable int bookId) {
		bookService.deleteBook(bookId,id);
		return "redirect:/";
		
	}
	
}
