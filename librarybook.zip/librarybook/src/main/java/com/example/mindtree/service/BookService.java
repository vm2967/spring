package com.example.mindtree.service;


import java.util.List;


import com.example.mindtree.entity.Book;

public interface BookService {

	List<Book> getListOfBooks(int libraryId);

	void addBook(Book book, int id);

	Book updatebook(int bookId);

	void saveUpdated(Book book, int id);

	void deleteBook(int bookId, int id);

}
