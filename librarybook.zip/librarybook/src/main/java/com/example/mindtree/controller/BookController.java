package com.example.mindtree.controller;


public class BookController {
//	@Autowired
//	BookService bookService;
	
	//static int id=0;
	
	

}
