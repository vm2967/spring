package com.example.mindtree.service;

import java.util.List;

import com.example.mindtree.entity.Library;

public interface LibraryService {

	List<Library> listLibrary();

	void addLibrary(Library library);

	void deleteLibrary(int libraryId);

	Library updateLibraryById(int libraryId);

}
