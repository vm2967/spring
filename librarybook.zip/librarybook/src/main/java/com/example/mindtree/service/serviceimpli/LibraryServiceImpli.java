package com.example.mindtree.service.serviceimpli;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mindtree.entity.Library;
import com.example.mindtree.repository.LibraryRepository;
import com.example.mindtree.service.LibraryService;
@Service
public class LibraryServiceImpli implements LibraryService {

	@Autowired
	LibraryRepository libraryRepo;
	@Override
	public List<Library> listLibrary() {
		List<Library> list=libraryRepo.findAll();
		return list;
		
		
	}
	@Override
	public void addLibrary(Library library) {
		libraryRepo.save(library);
	}
	@Override
	public void deleteLibrary(int libraryId) {
		libraryRepo.deleteById(libraryId);
		
	}
	@Override
	public Library updateLibraryById(int libraryId) {
		
		return libraryRepo.findById(libraryId).orElse(null);
	}

}
