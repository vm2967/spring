package com.example.mindtree.service.serviceimpli;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mindtree.entity.Book;
import com.example.mindtree.entity.Library;
import com.example.mindtree.repository.BookRepository;
import com.example.mindtree.repository.LibraryRepository;
import com.example.mindtree.service.BookService;
@Service
public class BookServiceImpli  implements BookService{
@Autowired
LibraryRepository libraryRepo;

@Autowired 
BookRepository bookRepo;

	@Override
	public List<Book> getListOfBooks(int libraryId) {
		Library library=libraryRepo.findById(libraryId).orElse(null);
		List<Book> list=library.getBooks();
				return list ;
	}

	@Override
	public void addBook(Book book, int id) {
		Library library=libraryRepo.findById(id).orElse(null);
		book.setLibrary(library);
		bookRepo.save(book);
	}

	@Override
	public Book updatebook(int bookId) {
		Book book=bookRepo.findById(bookId).orElse(null);
		
		return book;
	}

	@Override
	public void saveUpdated(Book book, int id) {
		Library library=libraryRepo.findById(id).orElse(null);
		book.setLibrary(library);
		bookRepo.save(book);
	
		
	}

	@Override
	public void deleteBook(int bookId, int id) {
		Library library=libraryRepo.findById(id).orElse(null);
		Book book=bookRepo.findById(bookId).orElse(null);
		library.getBooks().remove(book);
		libraryRepo.save(library);
		bookRepo.deleteById(bookId);
		
	}

}
