package com.mindtree.bikecompanyapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BikeCompanyAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
