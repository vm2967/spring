package com.mindtree.bikecompanyapp.service;

import java.util.List;

import com.mindtree.bikecompanyapp.entity.Company;


public interface CompanyService {

public void save(Company company);

public List<Company> listAll();

public Company findById(long id);

public Company findByName(String name);

}
