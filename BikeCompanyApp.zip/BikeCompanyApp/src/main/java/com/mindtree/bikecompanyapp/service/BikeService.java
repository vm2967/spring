package com.mindtree.bikecompanyapp.service;

import java.util.List;

import com.mindtree.bikecompanyapp.entity.Bike;

public interface BikeService {

	public void save(Bike bike);

	public Bike getbikebyid(long id);

	public List<Bike> listAll();

	public void updatedcompanydetails(long id);

}
