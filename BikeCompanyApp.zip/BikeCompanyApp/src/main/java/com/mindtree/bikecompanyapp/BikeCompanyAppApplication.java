package com.mindtree.bikecompanyapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BikeCompanyAppApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(BikeCompanyAppApplication.class, args);
	}

}
