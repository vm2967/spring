package com.mindtree.bikecompanyapp.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Company {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String name;
	private int noOfModels;
	private String vehicletype;
	@ElementCollection
	private List<String> branch;
	@OneToMany(mappedBy = "company", cascade = CascadeType.ALL)
	private List<Bike> bikelist;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getNoOfModels() {
		return noOfModels;
	}
	public void setNoOfModels(int noOfModels) {
		this.noOfModels = noOfModels;
	}
	public Company(String name, int noOfModels, String vehicletype, List<String> branch, List<Bike> bikelist) {
		this.name = name;
		this.noOfModels = noOfModels;
		this.vehicletype = vehicletype;
		this.branch = branch;
		this.bikelist = bikelist;
	}
	public String getVehicletype() {
		return vehicletype;
	}
	public void setVehicletype(String vehicletype) {
		this.vehicletype = vehicletype;
	}
	public List<String> getBranch() {
		return branch;
	}
	public void setBranch(List<String> branch) {
		this.branch = branch;
	}
	public List<Bike> getBikelist() {
		return bikelist;
	}
	public void setBikelist(List<Bike> bikelist) {
		this.bikelist = bikelist;
	}
	public Company() {
	}
	@Override
	public String toString() {
		return "Company [id=" + id + ", name=" + name + ", noOfModels=" + noOfModels + ", vehicletype=" + vehicletype
				+ ", branch=" + branch + ", bikelist=" + bikelist + "]";
	}
	

}
