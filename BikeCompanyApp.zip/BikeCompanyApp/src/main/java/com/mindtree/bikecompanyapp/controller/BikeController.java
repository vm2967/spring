package com.mindtree.bikecompanyapp.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mindtree.bikecompanyapp.entity.Bike;
import com.mindtree.bikecompanyapp.entity.Company;
import com.mindtree.bikecompanyapp.service.BikeService;
import com.mindtree.bikecompanyapp.service.CompanyService;

@Controller
public class BikeController {

	@Autowired
	private CompanyService companyservice;
	@Autowired
	private BikeService bikeservice;

	Company company1 = null;

	@RequestMapping(value = "/addbike")
	public String bookDetails(Model model) {
		List<Company> companylist = new ArrayList<Company>();
		Bike bike = new Bike();
		model.addAttribute("bike", bike);
		companylist = companyservice.listAll();
		model.addAttribute("companylist", companylist);
		return "inputbike";
	}

//	@RequestMapping(value = "/getcompanyname", method = RequestMethod.POST)
//	public String getcompanyname(@RequestParam(value = "name") String name,Model model) {
//		List<Company> companylist = new ArrayList<Company>();
//		companylist = companyservice.listAll();
//		model.addAttribute("companylist", companylist);
//		Bike bike = new Bike();
//		model.addAttribute("bike", bike);
//
//		System.out.println(name);
//		company = companyservice.findByName(name);
//		return "inputbike";
//	}

	@RequestMapping(value = "/savebike")
	public String saveLibrary(@ModelAttribute("bike") Bike bike, @RequestParam(value = "companyId") long id) {
		System.out.println(id);
		Company company2 = new Company();
		company2 = companyservice.findById(id);
		bike.setCompany(company2);
		bikeservice.save(bike);
		return "redirect:/";

	}

	@RequestMapping(value = "/showdetails")
	public String showbikes(Model model) {
		List<Company> CompanyList = companyservice.listAll();
		model.addAttribute("CompanyList", CompanyList);
		return "displaybikepage";
	}

	@RequestMapping(value = "/show", method = { RequestMethod.POST, RequestMethod.GET })
	public String viewbikes(@RequestParam(value = "company") String name, Model model) {
		List<Company> CompanyList = companyservice.listAll();
		model.addAttribute("CompanyList", CompanyList);
		company1 = companyservice.findByName(name);
		model.addAttribute("bikelist", company1.getBikelist());

		return "displaybikepage";
	}

	@RequestMapping(value = "/updatebike/{id}")
	public String editbike(@PathVariable long id, Model model) {
		System.out.println(id);
		Bike bikeobj = bikeservice.getbikebyid(id);
		model.addAttribute("bike", bikeobj);
		return "editbikepage";
	}

	@RequestMapping(value = "/editsave", method = RequestMethod.POST)
	public String editbikesave(@ModelAttribute("bike") Bike bike) {

		bike.setCompany(company1);
		bikeservice.save(bike);
		return "redirect:/";
	}

	@RequestMapping(value = "/buybike/{id}")
	public ModelAndView buybike(@PathVariable long id) {
		
	    ModelAndView mav=new ModelAndView("buybikepage");
	    List<Bike>bikes=bikeservice.listAll();
		Bike bikeobj = bikeservice.getbikebyid(id);
		mav.addObject("bike",bikes);
		mav.addObject("bike", bikeobj);
		return mav;
	}

	@RequestMapping(value = "/buysave/{id}")
	public String buybikeab(@PathVariable long id,@ModelAttribute("bike") Bike bike) {
		
	bikeservice.updatedcompanydetails(id);
		return "redirect:/";
	}

}
