package com.mindtree.bikecompanyapp.service.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.bikecompanyapp.entity.Company;
import com.mindtree.bikecompanyapp.repository.CompanyRepository;
import com.mindtree.bikecompanyapp.service.CompanyService;

@Service
public class CompanyServiceImplementation implements CompanyService {
	
	@Autowired
	private CompanyRepository companyrepository;

	@Override
	public void save(Company company) {
		companyrepository.save(company);
		
	}

	@Override
	public List<Company> listAll() {
		
		return companyrepository.findAll();
	}


	@Override
	public Company findById(long id) {
		
		return companyrepository.findById(id).get();
	}

	@Override
	public Company findByName(String name) {
	
		return companyrepository.findByName(name);
	}

}
