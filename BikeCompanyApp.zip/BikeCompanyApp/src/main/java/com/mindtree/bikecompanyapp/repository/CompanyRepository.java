package com.mindtree.bikecompanyapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.bikecompanyapp.entity.Company;
@Repository
public interface CompanyRepository extends JpaRepository<Company, Long> {

	public Company findByName(String name);



}
