package com.mindtree.bikecompanyapp.service.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.bikecompanyapp.entity.Bike;
import com.mindtree.bikecompanyapp.entity.Company;
import com.mindtree.bikecompanyapp.repository.BikeRepository;
import com.mindtree.bikecompanyapp.repository.CompanyRepository;
import com.mindtree.bikecompanyapp.service.BikeService;

@Service
public class BikeServiceImplementation implements BikeService {
	@Autowired
	BikeRepository bikerepository;
	@Autowired
	private CompanyRepository companyrepository;

	@Override
	public void save(Bike bike) {

		bikerepository.save(bike);
	}

	@Override
	public Bike getbikebyid(long id) {

		return bikerepository.findById(id).get();
	}

	@Override
	public List<Bike> listAll() {

		return bikerepository.findAll();
	}

	@Override
	public void updatedcompanydetails(long id) {
		Bike bikeobj=bikerepository.findById(id).orElse(null);
		Company company=bikeobj.getCompany();
		int current=company.getNoOfModels();
		current=current-1;
		company.setNoOfModels(current);
		companyrepository.save(company);
	}

}
