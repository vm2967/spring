package com.mindtree.bikecompanyapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.mindtree.bikecompanyapp.entity.Bike;
import com.mindtree.bikecompanyapp.entity.Company;
import com.mindtree.bikecompanyapp.service.BikeService;
import com.mindtree.bikecompanyapp.service.CompanyService;

@Controller
public class CompanyController {

	@Autowired
	private CompanyService companyservice;
	@Autowired
	private BikeService bikeservice;
	
	
	@RequestMapping(value = "/")
	public String viewindex() {
		return "index";
	}
	
	@RequestMapping(value = "/addcompany")
	public String addCompany(Model model) {
		Company companyobj = new Company();
		model.addAttribute("company", companyobj);
		return "inputcompany";
	}

	@RequestMapping(value = "/savecompany", method = RequestMethod.POST)
	public String saveCompany(@ModelAttribute("company") Company company) {
		companyservice.save(company);
		return "redirect:/addcompany";

	}
	
}
