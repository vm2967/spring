/**
 * 
 */
function validation()
{
var name=document.getElementById("name").value;
var namevalidation=/^[A-Za-z]+$/;
if(name==="")
	{
	alert("name cant be empty");
	return false;
	}
  if(!(namevalidation.test(name)))
	  {
	  alert("enter a valid name");
	  return false;
	  }
var name1=document.getElementById("color").value;
if(name1==="")
{
alert("color cant be empty");
return false;
}
if(!(namevalidation.test(name1)))
  {
  alert("enter a valid color");
  return false;
  }
}