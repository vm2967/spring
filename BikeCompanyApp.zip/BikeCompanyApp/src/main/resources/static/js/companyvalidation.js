/**
 * 
 */
// function validation()
// {
// var name=document.getElementById("name").value;
// var noOfModel=document.getElementById("noOfModel").value;
// var namevalidation=/^[A-Za-z]+$/;
// if(name==="")
// {
// alert("name cant be empty");
// return false;
//	
// }
//    
// if(!(namevalidation.test(name)))
// {
//    	
// alert("enter a valid name");
// return false;
// }
// if(noOfModel<=0)
// {
// alert("no of model cant be negative or empty");
// return false;
// }
// var type=document.getElementById("type").value;
// if(type==="")
// {
// alert("choose vehicle type");
// return false;
// }
//   
// var count=0;
// if(document.getElementById("delhi").checked)
// count++;
// if(document.getElementById("pune").checked)
// count++;
// if(document.getElementById("kolkata").checked)
// count++;
// if(count>=2)
// {
// return true;
// }
// else
// {
// alert("choose atleast two branch");
// return false;
// }
// count1=0;
// if(document.getElementById("two").checked)
// count1++;
// if(document.getElementById("four").checked)
// count1++;
// if(count1===0)
// alert("choose vehicle type");
//
//
// }
$(function() {
			$("#errname").hide();
			$("#errnoOfModel").hide();
			$("#errvehicletype").hide();
			$("#errbranch").hide();
			count = 0;
			var errname = true;
			var errnoOfModel = true;
			var errvehicletype = true;
			var errbranch = true;

			$("#name").focusout(function() {

				check_name();
			});
			$("#noOfModel").focusout(function() {

				check_noOfModel();
			});
			$("#delhi").focusout(function() {

				check_delhi();
			});
			$("#pune").focusout(function() {

				check_pune();
			});
			$("#kolkata").focusout(function() {

				check_kolkata();
			});
			$("#two").focusout(function() {
				check_two();
			});
			$("#four").focusout(function() {
				check_four();
			});

			function check_name() {
				var pattern = /^[a-zA-Z]+$/;
				var name = $("#name").val();
				if (pattern.test(name) && name !== "") {
					$("#errname").hide();

				} else {
					$("#errname").html("alphabets only");
					$("#errname").show();
					errname = false;
				}

			}
			function check_noOfModel() {
				var model = $("#noOfModel").val();
				if (model > 0) {
					$("#errnoOfModel").hide();
				} else {
					$("#errnoOfModel").html(" cant be 0");
					$("#errnoOfModel").show();
					errnoOfModel = false;
				}

			}
			function check_two() {
				var c = $("#two").val();
				if (c !== '') {
					count++;
				}
			}
			function check_four() {
				var c = $("#four").val();
				if (c !== '') {
					count++;
				}

			}
			function check() {
			var type=$("input[type=radio]:checked").val();
			if(type===undefined)
				{
				$("#errvehicletype").html("choose one");
				$("#errvehicletype").show();
				 errvehicletype = false;

				}
			}
			function checkboxcheck() {
				checked = $("#check input[type=checkbox]:checked").length;
				alert(checked);
				if (checked >= 2) {

					$("#errbranch").hide();
				}
				else{
				$("#errbranch").html("choose at least two");
				$("#errbranch").show();
			     errbranch = false;
				}

			}

			$("#form").submit(
					function() {
						 errname = true;
						 errnoOfModel = true;
						 errvehicletype = true;
						 errbranch = true;

						alert("hello");
						check_name();
						check_noOfModel();
						check();
						checkboxcheck();
						alert(errbranch);
						if (errname === true && errnoOfModel === true
								&& errvehicletype === true
								&& errbranch === true) {
							alert("added");
							return true;
						} else {
							alert(" please fill the form");
							return false;
						}

					});
		});