package com.mindtree.industryshow.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.industryshow.dto.EmployeeDto;
import com.mindtree.industryshow.entity.Employee;
import com.mindtree.industryshow.entity.Industry;
import com.mindtree.industryshow.exception.IndustryNotFoundException;
import com.mindtree.industryshow.exception.ServiceException;
import com.mindtree.industryshow.repository.EmployeeRepository;
import com.mindtree.industryshow.repository.IndustryRepository;
import com.mindtree.industryshow.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepo;
	@Autowired
	private IndustryRepository industryRepo;
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public EmployeeDto addIndustry(EmployeeDto employeeDto, int industryId) {
		Industry industry = industryRepo.findById(industryId).orElse(null);
		Employee employee = modelMapper.map(employeeDto, Employee.class);
		employee.setIndustry(industry);
		employeeRepo.save(employee);
		return employeeDto;
	}

	@Override
	public List<EmployeeDto> displayEmployees(String industryName) throws ServiceException {
		Industry industry = industryRepo.findByIndustryName(industryName)
				.orElseThrow(() -> new IndustryNotFoundException("Industry Not Found for this Name"));
		List<Employee> empList=industry.getEmployees();
		List<EmployeeDto>empDtoList=new ArrayList<EmployeeDto>();
		empList.forEach(e->empDtoList.add(modelMapper.map(e, EmployeeDto.class)));
		return empDtoList;
	}

	@Override
	public String updateEmpSalary() {
		List<Employee> emplList=employeeRepo.findAll();
		List<Employee> empList1=emplList.stream().filter(e->e.getempSalary()<20000).collect(Collectors.toList());
		
		for (Employee employee : empList1) {
			employee.setempSalary(employee.getempSalary()*2);
			
			
		}
		employeeRepo.saveAll(empList1);
		
		return "updatedSuccessfully";
	}
	

}
