package com.mindtree.industryshow.entity;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Employee{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int empId;
	private String empName;
	private int empAge;
	private double empSalary;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	private Industry industry;

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int empId, String empName, int empAge, double empSalary, Industry industry) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empAge = empAge;
		this.empSalary = empSalary;
		this.industry = industry;
	}

	public int getempId() {
		return empId;
	}

	public void setempId(int empId) {
		this.empId = empId;
	}

	public String getempName() {
		return empName;
	}

	public void setempName(String empName) {
		this.empName = empName;
	}

	public int getempAge() {
		return empAge;
	}

	public void setempAge(int empAge) {
		this.empAge = empAge;
	}

	public double getempSalary() {
		return empSalary;
	}

	public void setempSalary(double empSalary) {
		this.empSalary = empSalary;
	}

	public Industry getIndustry() {
		return industry;
	}

	public void setIndustry(Industry industry) {
		this.industry = industry;
	}
	
	
	
	

}
