package com.mindtree.industryshow.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Industry {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int indusId;
	private String indusName;
	
	@OneToMany(fetch =FetchType.EAGER,cascade = CascadeType.ALL,mappedBy = "industry")
	List<Employee> employees;

	public Industry() {
		super();
		
	}

	public Industry(int indusId, String indusName, List<Employee> employees) {
		super();
		this.indusId = indusId;
		this.indusName = indusName;
		this.employees = employees;
	}

	public int getindusId() {
		return indusId;
	}

	public void setindusId(int indusId) {
		this.indusId = indusId;
	}

	public String getindusName() {
		return indusName;
	}

	public void setindusName(String indusName) {
		this.indusName = indusName;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
	

}
