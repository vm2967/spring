package com.mindtree.industryshow.service;

import com.mindtree.industryshow.dto.IndustryDto;

public interface IndustryService {

	IndustryDto addIndustry(IndustryDto industryDto);

}
