package com.mindtree.industryshow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IndustryshowApplication {

	public static void main(String[] args) {
		SpringApplication.run(IndustryshowApplication.class, args);
	}

}
