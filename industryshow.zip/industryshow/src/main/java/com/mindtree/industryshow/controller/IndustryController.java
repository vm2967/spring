package com.mindtree.industryshow.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.industryshow.dto.IndustryDto;
import com.mindtree.industryshow.service.IndustryService;

@RestController
public class IndustryController {
	
	@Autowired
	private IndustryService industryService;
	
	@PostMapping(value="/addIndustryOnly")
	public ResponseEntity<?> addOnlyIndustry(@RequestBody IndustryDto industryDto){
		
		IndustryDto industryDto2=industryService.addIndustry(industryDto);
		return new ResponseEntity<IndustryDto>(industryDto2, HttpStatus.ACCEPTED);
		
		
	}

}
