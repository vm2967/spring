package com.mindtree.industryshow.service.serviceimpl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.industryshow.dto.IndustryDto;
import com.mindtree.industryshow.entity.Industry;
import com.mindtree.industryshow.repository.IndustryRepository;
import com.mindtree.industryshow.service.IndustryService;

@Service
public class IndustryServiceImpl implements IndustryService {

	
	@Autowired
	private IndustryRepository industryRepo;
	@Autowired
	private ModelMapper modelMapper;
	
	@Override
	public IndustryDto addIndustry(IndustryDto industryDto) {
		Industry industry=modelMapper.map(industryDto, Industry.class);
		industryRepo.save(industry);
		return industryDto;
	}

}
