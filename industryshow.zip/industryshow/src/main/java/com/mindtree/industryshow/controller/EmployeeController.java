package com.mindtree.industryshow.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.industryshow.dto.EmployeeDto;
import com.mindtree.industryshow.exception.ApplicationException;
import com.mindtree.industryshow.service.EmployeeService;

@RestController
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	
	@PostMapping(value="/addEmployeeWithIndustry/{industryId}")
	public ResponseEntity<?> addEmployee(@RequestBody EmployeeDto employeeDto ,@PathVariable int industryId){
		EmployeeDto employeeDto2=employeeService.addIndustry(employeeDto,industryId);
		return new ResponseEntity<EmployeeDto>(employeeDto2, HttpStatus.ACCEPTED);
		
		
	}
	
	@GetMapping(value="/displayEmployeesOnly/{industryName}")
	public ResponseEntity<?> displayEmployees(@PathVariable String industryName) throws ApplicationException{
		List<EmployeeDto> empdtoList=employeeService.displayEmployees(industryName);
		return new ResponseEntity<List<EmployeeDto>>(empdtoList, HttpStatus.FOUND);
		
	}
	
	@GetMapping(value="/updateEmployeeSalary")
	public ResponseEntity<?> updateEmployeeSalary(){
		String str=employeeService.updateEmpSalary();
		return new ResponseEntity<String>(str, HttpStatus.ACCEPTED);
	}
	
	
	
	
	

}
