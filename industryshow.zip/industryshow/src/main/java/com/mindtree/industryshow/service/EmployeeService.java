package com.mindtree.industryshow.service;

import java.util.List;

import com.mindtree.industryshow.dto.EmployeeDto;
import com.mindtree.industryshow.exception.ServiceException;

public interface EmployeeService {

	EmployeeDto addIndustry(EmployeeDto employeeDto, int industryId);

	List<EmployeeDto> displayEmployees(String industryName) throws ServiceException;

	String updateEmpSalary();

}
