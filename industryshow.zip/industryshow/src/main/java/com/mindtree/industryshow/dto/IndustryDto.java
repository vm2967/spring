package com.mindtree.industryshow.dto;


public class IndustryDto {

	private int industryId;
	private String industryName;
	
	public IndustryDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public IndustryDto(int industryId, String industryName) {
		super();
		this.industryId = industryId;
		this.industryName = industryName;
	}
	public int getIndustryId() {
		return industryId;
	}
	public void setIndustryId(int industryId) {
		this.industryId = industryId;
	}
	public String getIndustryName() {
		return industryName;
	}
	public void setIndustryName(String industryName) {
		this.industryName = industryName;
	}
	
}
